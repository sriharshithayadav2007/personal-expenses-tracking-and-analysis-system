import React, { useMemo } from 'react';
import {
  TrendingUp,
  Plus,
  Trash2,
  Edit2,
  DollarSign,
  Calendar,
  Briefcase,
  PieChart as PieChartIcon,
} from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { useAuth } from '../../context/AuthContext';
import { useExpense } from '../../context/ExpenseContext';
import { Income } from '../../types';

interface IncomeViewProps {
  onOpenAddIncome: () => void;
  onEditIncome: (inc: Income) => void;
}

export const IncomeView: React.FC<IncomeViewProps> = ({
  onOpenAddIncome,
  onEditIncome,
}) => {
  const { currency } = useAuth();
  const { incomes, totalIncome, deleteIncome } = useExpense();

  // Income by Source breakdown
  const sourceBreakdown = useMemo(() => {
    const map: Record<string, number> = {};
    incomes.forEach(i => {
      map[i.source] = (map[i.source] || 0) + i.amount;
    });
    return Object.entries(map).map(([source, amount]) => ({
      source,
      amount,
      percentage: totalIncome > 0 ? Math.round((amount / totalIncome) * 100) : 0,
    }));
  }, [incomes, totalIncome]);

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white font-['Space_Grotesk']">
            Income Management
          </h1>
          <p className="text-xs text-neutral-400">
            Log salaries, dividends, retainer contracts, and cash credits
          </p>
        </div>

        <button
          onClick={onOpenAddIncome}
          className="flex items-center justify-center gap-1.5 rounded-xl bg-white px-4 py-2.5 text-xs font-bold text-black hover:bg-neutral-200 active:scale-95 transition-all shadow-md self-start sm:self-auto"
        >
          <Plus className="h-4 w-4 stroke-[2.5]" />
          <span>Add Income</span>
        </button>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-5 backdrop-blur-xl">
          <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
            Total Inflow
          </span>
          <div className="mt-2 text-2xl sm:text-3xl font-extrabold tracking-tight text-emerald-400 font-['Space_Grotesk']">
            {currency}
            {totalIncome.toLocaleString()}
          </div>
          <p className="mt-1 text-[11px] text-neutral-400">Cumulative recorded income</p>
        </div>

        <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-5 backdrop-blur-xl">
          <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
            Active Streams
          </span>
          <div className="mt-2 text-2xl sm:text-3xl font-extrabold tracking-tight text-white font-['Space_Grotesk']">
            {sourceBreakdown.length}
          </div>
          <p className="mt-1 text-[11px] text-neutral-400">Diversified revenue sources</p>
        </div>

        <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-5 backdrop-blur-xl">
          <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
            Average Credit
          </span>
          <div className="mt-2 text-2xl sm:text-3xl font-extrabold tracking-tight text-white font-['Space_Grotesk']">
            {currency}
            {incomes.length > 0 ? Math.round(totalIncome / incomes.length).toLocaleString() : 0}
          </div>
          <p className="mt-1 text-[11px] text-neutral-400">Per transaction deposit</p>
        </div>
      </div>

      {/* Sources Breakdown Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Source cards list */}
        <div className="lg:col-span-1 rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-5 backdrop-blur-xl">
          <h2 className="text-sm font-bold text-white pb-3 border-b border-neutral-900">
            Revenue Source Breakdown
          </h2>
          <div className="mt-4 space-y-3">
            {sourceBreakdown.map(item => (
              <div key={item.source} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-white">{item.source}</span>
                  <span className="font-mono text-neutral-300">
                    {currency}
                    {item.amount.toLocaleString()} ({item.percentage}%)
                  </span>
                </div>
                <div className="h-1.5 w-full rounded-full bg-neutral-900 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-emerald-400 transition-all duration-500"
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Incomes Table (2 cols) */}
        <div className="lg:col-span-2 rounded-2xl border border-neutral-800/80 bg-neutral-950/70 backdrop-blur-xl overflow-hidden">
          <div className="p-4 border-b border-neutral-900 flex items-center justify-between">
            <h2 className="text-sm font-bold text-white">Deposit Records</h2>
            <span className="text-xs text-neutral-500 font-mono">{incomes.length} credits</span>
          </div>

          {incomes.length === 0 ? (
            <div className="p-12 text-center text-xs text-neutral-500">
              No income entries recorded yet. Tap "Add Income" to record a salary or retainer.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-neutral-900 bg-neutral-900/40 text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
                  <tr>
                    <th className="py-3 pl-6 pr-4">Source</th>
                    <th className="py-3 px-4">Notes</th>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4 text-right">Amount</th>
                    <th className="py-3 pr-6 pl-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-900">
                  {incomes.map(item => (
                    <tr key={item.id} className="group hover:bg-neutral-900/40 transition-colors">
                      <td className="py-3 pl-6 pr-4 font-semibold text-white flex items-center gap-2">
                        <div className="h-2 w-2 rounded-full bg-emerald-400" />
                        <span>{item.source}</span>
                      </td>
                      <td className="py-3 px-4 text-neutral-400 max-w-xs truncate">
                        {item.notes || '—'}
                      </td>
                      <td className="py-3 px-4 font-mono text-neutral-400 whitespace-nowrap">
                        {item.date}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-emerald-400 whitespace-nowrap">
                        +{currency}
                        {item.amount.toLocaleString()}
                      </td>
                      <td className="py-3 pr-6 pl-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => onEditIncome(item)}
                            className="rounded-lg p-1.5 text-neutral-400 hover:bg-neutral-800 hover:text-white"
                          >
                            <Edit2 className="h-3.5 w-3.5" />
                          </button>
                          <button
                            onClick={() => deleteIncome(item.id)}
                            className="rounded-lg p-1.5 text-neutral-400 hover:bg-neutral-800 hover:text-rose-400"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
