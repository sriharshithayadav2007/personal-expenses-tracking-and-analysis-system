import React, { useState } from 'react';
import {
  FileText,
  Download,
  Printer,
  FileSpreadsheet,
  FileCode,
  Calendar,
  CheckCircle,
  Share2,
  Layers,
  Server,
  ExternalLink,
  FolderArchive,
  GitBranch,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useExpense } from '../../context/ExpenseContext';
import { exportToCSV, exportToExcel, exportToJSON, printFinancialReport } from '../../utils/export';

export const ReportsView: React.FC = () => {
  const { currency } = useAuth();
  const {
    expenses,
    incomes,
    budgets,
    totalIncome,
    totalExpenses,
    balance,
    categoryBreakdown,
  } = useExpense();

  const [exportSuccess, setExportSuccess] = useState<string | null>(null);

  const handleExport = (type: 'pdf' | 'csv' | 'excel' | 'json') => {
    if (type === 'pdf') {
      printFinancialReport({
        expenses,
        incomes,
        budgets,
        currency,
        totalIncome,
        totalExpenses,
        balance,
        categoryBreakdown,
      });
      setExportSuccess('PDF print dialogue opened.');
    } else if (type === 'csv') {
      exportToCSV(expenses, currency);
      setExportSuccess('CSV downloaded successfully.');
    } else if (type === 'excel') {
      exportToExcel(expenses, incomes, currency);
      setExportSuccess('Excel sheet downloaded successfully.');
    } else if (type === 'json') {
      exportToJSON({ expenses, incomes, budgets });
      setExportSuccess('Full JSON backup downloaded.');
    }

    setTimeout(() => {
      setExportSuccess(null);
    }, 4000);
  };

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div>
        <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white font-['Space_Grotesk']">
          Financial Reports & Export
        </h1>
        <p className="text-xs text-neutral-400">
          Generate audit-ready statements in PDF, Excel, CSV, or raw JSON backup
        </p>
      </div>

      {exportSuccess && (
        <div className="flex items-center gap-2 rounded-2xl border border-emerald-900/60 bg-emerald-950/30 p-3.5 text-xs text-emerald-300 animate-in fade-in">
          <CheckCircle className="h-4 w-4 shrink-0 text-emerald-400" />
          <span>{exportSuccess}</span>
        </div>
      )}

      {/* Export Action Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* PDF Export */}
        <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-5 backdrop-blur-xl flex flex-col justify-between hover:border-neutral-700 transition-all">
          <div>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-black font-bold mb-3">
              <Printer className="h-5 w-5" />
            </div>
            <h3 className="text-sm font-bold text-white">Printable PDF Statement</h3>
            <p className="mt-1 text-xs text-neutral-400 leading-relaxed">
              Formatted official summary statement with totals, category distribution, and transactions.
            </p>
          </div>
          <button
            onClick={() => handleExport('pdf')}
            className="mt-4 flex w-full items-center justify-center gap-1.5 rounded-xl bg-white py-2 px-3 text-xs font-bold text-black hover:bg-neutral-200 active:scale-95 transition-all shadow-md"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Generate PDF</span>
          </button>
        </div>

        {/* Excel Export */}
        <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-5 backdrop-blur-xl flex flex-col justify-between hover:border-neutral-700 transition-all">
          <div>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-neutral-900 text-white font-bold mb-3">
              <FileSpreadsheet className="h-5 w-5" />
            </div>
            <h3 className="text-sm font-bold text-white">Excel Spreadsheet (.xls)</h3>
            <p className="mt-1 text-xs text-neutral-400 leading-relaxed">
              Dual-tab workbook containing Expenses, Incomes, and calculated balance formulas.
            </p>
          </div>
          <button
            onClick={() => handleExport('excel')}
            className="mt-4 flex w-full items-center justify-center gap-1.5 rounded-xl border border-neutral-800 bg-neutral-900 py-2 px-3 text-xs font-semibold text-white hover:border-neutral-700 hover:bg-neutral-800 active:scale-95 transition-all"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export Excel</span>
          </button>
        </div>

        {/* CSV Export */}
        <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-5 backdrop-blur-xl flex flex-col justify-between hover:border-neutral-700 transition-all">
          <div>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-neutral-900 text-white font-bold mb-3">
              <FileText className="h-5 w-5" />
            </div>
            <h3 className="text-sm font-bold text-white">Standard CSV (.csv)</h3>
            <p className="mt-1 text-xs text-neutral-400 leading-relaxed">
              Universal comma-separated text file suitable for importing into accounting software.
            </p>
          </div>
          <button
            onClick={() => handleExport('csv')}
            className="mt-4 flex w-full items-center justify-center gap-1.5 rounded-xl border border-neutral-800 bg-neutral-900 py-2 px-3 text-xs font-semibold text-white hover:border-neutral-700 hover:bg-neutral-800 active:scale-95 transition-all"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export CSV</span>
          </button>
        </div>

        {/* JSON Backup */}
        <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-5 backdrop-blur-xl flex flex-col justify-between hover:border-neutral-700 transition-all">
          <div>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-neutral-900 text-white font-bold mb-3">
              <FileCode className="h-5 w-5" />
            </div>
            <h3 className="text-sm font-bold text-white">JSON Archive (.json)</h3>
            <p className="mt-1 text-xs text-neutral-400 leading-relaxed">
              Complete machine-readable snapshot of your expenses, incomes, and category budgets.
            </p>
          </div>
          <button
            onClick={() => handleExport('json')}
            className="mt-4 flex w-full items-center justify-center gap-1.5 rounded-xl border border-neutral-800 bg-neutral-900 py-2 px-3 text-xs font-semibold text-white hover:border-neutral-700 hover:bg-neutral-800 active:scale-95 transition-all"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Download Backup</span>
          </button>
        </div>
      </div>

      {/* Engineering Architecture Whitepapers (PDF Downloads) */}
      <div className="rounded-2xl border border-neutral-800/90 bg-neutral-950/80 p-6 backdrop-blur-xl space-y-4">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full border border-neutral-800 bg-neutral-900/80 px-2.5 py-0.5 text-[10px] font-mono uppercase tracking-wider text-neutral-300 mb-2">
            System Documentation
          </div>
          <h2 className="text-base font-bold text-white font-['Space_Grotesk']">
            Frontend & Backend Architecture Specifications (PDF)
          </h2>
          <p className="text-xs text-neutral-400">
            Official engineering whitepapers documenting the complete frontend React SPA framework and backend Cloud Firestore / Gemini AI architecture.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          {/* Frontend Architecture PDF */}
          <div className="rounded-xl border border-neutral-800 bg-neutral-900/50 p-5 flex flex-col justify-between hover:border-neutral-700 transition-all">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-black font-black">
                  <Layers className="h-5 w-5" />
                </div>
                <span className="text-[10px] font-mono text-neutral-400 border border-neutral-800 px-2 py-0.5 rounded">
                  DOC ID: FE-SPEC-001
                </span>
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Frontend Architecture Specification</h3>
                <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                  Deep technical breakdown of React 19 SPA, Tailwind CSS v4 design tokens, client-side caching & state sync, Recharts financial data visualization, and accessibility standards.
                </p>
              </div>
              <div className="flex flex-wrap gap-1.5 pt-1 text-[10px] font-mono text-neutral-300">
                <span className="bg-neutral-800 px-2 py-0.5 rounded">React 19</span>
                <span className="bg-neutral-800 px-2 py-0.5 rounded">Tailwind v4</span>
                <span className="bg-neutral-800 px-2 py-0.5 rounded">Recharts</span>
                <span className="bg-neutral-800 px-2 py-0.5 rounded">Framer Motion</span>
              </div>
            </div>

            <div className="mt-5 flex items-center gap-2">
              <a
                href="/downloads/Kuro_Frontend_Architecture.pdf"
                download="Kuro_Frontend_Architecture.pdf"
                className="flex-1 flex items-center justify-center gap-1.5 rounded-xl bg-white py-2 px-3 text-xs font-bold text-black hover:bg-neutral-200 active:scale-95 transition-all shadow-md"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Download Frontend PDF</span>
              </a>
              <a
                href="/docs/frontend-architecture.html"
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center rounded-xl border border-neutral-800 bg-neutral-900 p-2 text-neutral-300 hover:text-white hover:border-neutral-700 transition-all"
                title="View document in browser"
              >
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Backend Architecture PDF */}
          <div className="rounded-xl border border-neutral-800 bg-neutral-900/50 p-5 flex flex-col justify-between hover:border-neutral-700 transition-all">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-neutral-800 text-white font-black">
                  <Server className="h-5 w-5" />
                </div>
                <span className="text-[10px] font-mono text-neutral-400 border border-neutral-800 px-2 py-0.5 rounded">
                  DOC ID: BE-SPEC-002
                </span>
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Backend & Database Architecture Specification</h3>
                <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                  Comprehensive specification for Node.js REST microservices, Cloud Firestore schemas, Zero-Trust ABAC security rules, and Gemini 3.8 Flash neural financial auditor.
                </p>
              </div>
              <div className="flex flex-wrap gap-1.5 pt-1 text-[10px] font-mono text-neutral-300">
                <span className="bg-neutral-800 px-2 py-0.5 rounded">Cloud Firestore</span>
                <span className="bg-neutral-800 px-2 py-0.5 rounded">Express API</span>
                <span className="bg-neutral-800 px-2 py-0.5 rounded">Gemini 3.8 Flash</span>
                <span className="bg-neutral-800 px-2 py-0.5 rounded">ABAC Security</span>
              </div>
            </div>

            <div className="mt-5 flex items-center gap-2">
              <a
                href="/downloads/Kuro_Backend_Architecture.pdf"
                download="Kuro_Backend_Architecture.pdf"
                className="flex-1 flex items-center justify-center gap-1.5 rounded-xl bg-white py-2 px-3 text-xs font-bold text-black hover:bg-neutral-200 active:scale-95 transition-all shadow-md"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Download Backend PDF</span>
              </a>
              <a
                href="/docs/backend-architecture.html"
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center rounded-xl border border-neutral-800 bg-neutral-900 p-2 text-neutral-300 hover:text-white hover:border-neutral-700 transition-all"
                title="View document in browser"
              >
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>
          </div>
        </div>

        {/* GitHub Repository ZIP Archive Banner */}
        <div className="mt-4 rounded-xl border border-neutral-800 bg-neutral-900/60 p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white text-black font-black">
              <FolderArchive className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white">Full GitHub Repository Package (.ZIP)</h3>
                <span className="rounded bg-neutral-800 px-1.5 py-0.5 text-[10px] font-mono text-neutral-300">
                  424 KB
                </span>
              </div>
              <p className="mt-1 text-xs text-neutral-400 leading-relaxed max-w-xl">
                Ready-to-upload archive containing all 59 production files: React SPA, Express backend, Firestore security rules, Gemini AI auditor, unit tests, and README.md. Excludes heavy node_modules for instant upload.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <a
              href="/downloads/kuro-expense-source.zip"
              download="kuro-expense-source.zip"
              className="flex items-center justify-center gap-2 rounded-xl bg-white px-4 py-2.5 text-xs font-bold text-black hover:bg-neutral-200 active:scale-95 transition-all shadow-lg"
            >
              <Download className="h-4 w-4" />
              <span>Download ZIP Archive</span>
            </a>
          </div>
        </div>
      </div>

      {/* Live Report Statement Preview */}
      <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-6 backdrop-blur-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-neutral-900">
          <div>
            <h2 className="text-base font-bold text-white">Statement Preview</h2>
            <p className="text-xs text-neutral-400">
              Live calculation as of {new Date().toLocaleDateString('default', { dateStyle: 'long' })}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="rounded-lg border border-neutral-800 bg-neutral-900 px-3 py-1 text-xs font-mono text-neutral-300">
              Currency: {currency}
            </span>
          </div>
        </div>

        {/* Financial Summary KPIs */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="rounded-xl border border-neutral-800 bg-neutral-900/40 p-4">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400">
              Total Inflow (Income)
            </span>
            <div className="mt-1 text-xl font-mono font-bold text-emerald-400">
              {currency}
              {totalIncome.toLocaleString()}
            </div>
          </div>
          <div className="rounded-xl border border-neutral-800 bg-neutral-900/40 p-4">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400">
              Total Outflow (Expenses)
            </span>
            <div className="mt-1 text-xl font-mono font-bold text-white">
              {currency}
              {totalExpenses.toLocaleString()}
            </div>
          </div>
          <div className="rounded-xl border border-neutral-800 bg-neutral-900/40 p-4">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400">
              Net Savings Balance
            </span>
            <div
              className={`mt-1 text-xl font-mono font-bold ${
                balance >= 0 ? 'text-white' : 'text-rose-400'
              }`}
            >
              {currency}
              {balance.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Category Breakdown Table Preview */}
        <div>
          <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-2.5">
            Category Spending Distribution
          </h3>
          <div className="overflow-x-auto rounded-xl border border-neutral-900">
            <table className="w-full text-left text-xs">
              <thead className="bg-neutral-900/50 text-[11px] font-semibold text-neutral-400 uppercase tracking-wider border-b border-neutral-900">
                <tr>
                  <th className="py-2.5 px-4">Category</th>
                  <th className="py-2.5 px-4 text-right">Amount</th>
                  <th className="py-2.5 px-4 text-right">Percentage of Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-900">
                {Object.entries(categoryBreakdown)
                  .sort((a, b) => b[1] - a[1])
                  .map(([cat, amt]) => (
                    <tr key={cat} className="hover:bg-neutral-900/30">
                      <td className="py-2.5 px-4 font-semibold text-white">{cat}</td>
                      <td className="py-2.5 px-4 text-right font-mono text-neutral-300">
                        {currency}
                        {amt.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono text-neutral-400">
                        {totalExpenses > 0 ? Math.round((amt / totalExpenses) * 100) : 0}%
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
