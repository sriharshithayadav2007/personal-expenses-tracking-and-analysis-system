import { Expense, Income, Budget } from '../types';

export function exportToCSV(expenses: Expense[], currency: string = '₹') {
  const headers = ['ID', 'Date', 'Category', 'Description', 'Payment Method', `Amount (${currency})`, 'Notes'];
  const rows = expenses.map(e => [
    `"${e.id}"`,
    `"${e.date}"`,
    `"${e.category}"`,
    `"${e.description.replace(/"/g, '""')}"`,
    `"${e.paymentMethod}"`,
    e.amount,
    `"${(e.notes || '').replace(/"/g, '""')}"`,
  ]);

  const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  downloadBlob(csvContent, 'text/csv;charset=utf-8;', `kuro_expenses_${new Date().toISOString().slice(0, 10)}.csv`);
}

export function exportToExcel(expenses: Expense[], incomes: Income[], currency: string = '₹') {
  // Generates an Excel-compatible tab-delimited file or CSV with BOM
  let content = `\uFEFF=== KURO EXPENSE REPORT ===\nGenerated on: ${new Date().toLocaleString()}\nCurrency: ${currency}\n\n`;

  content += `EXPENSES\n`;
  content += ['Date', 'Category', 'Description', 'Payment Method', `Amount (${currency})`, 'Notes'].join('\t') + '\n';
  expenses.forEach(e => {
    content += [e.date, e.category, e.description, e.paymentMethod, e.amount, e.notes || ''].join('\t') + '\n';
  });

  content += `\nINCOME\n`;
  content += ['Date', 'Source', `Amount (${currency})`, 'Notes'].join('\t') + '\n';
  incomes.forEach(i => {
    content += [i.date, i.source, i.amount, i.notes || ''].join('\t') + '\n';
  });

  downloadBlob(content, 'application/vnd.ms-excel;charset=utf-8;', `kuro_financial_statement_${new Date().toISOString().slice(0, 10)}.xls`);
}

export function exportToJSON(data: { expenses: Expense[]; incomes: Income[]; budgets: Budget[] }) {
  const jsonContent = JSON.stringify(data, null, 2);
  downloadBlob(jsonContent, 'application/json', `kuro_backup_${new Date().toISOString().slice(0, 10)}.json`);
}

export function printFinancialReport(data: {
  expenses: Expense[];
  incomes: Income[];
  budgets: Budget[];
  currency: string;
  totalIncome: number;
  totalExpenses: number;
  balance: number;
  categoryBreakdown: Record<string, number>;
}) {
  const { expenses, incomes, currency, totalIncome, totalExpenses, balance, categoryBreakdown } = data;

  const printWindow = window.open('', '_blank');
  if (!printWindow) return;

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <title>Financial Report - Kuro Expense</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #fff; color: #111; padding: 40px; }
          .header { display: flex; justify-content: space-between; align-items: flex-end; border-bottom: 2px solid #111; padding-bottom: 20px; margin-bottom: 30px; }
          .title { font-size: 28px; font-weight: 800; letter-spacing: -0.5px; }
          .subtitle { font-size: 14px; color: #666; }
          .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px; }
          .card { border: 1px solid #e5e5e5; border-radius: 8px; padding: 16px; }
          .card-label { font-size: 12px; color: #777; text-transform: uppercase; letter-spacing: 0.5px; }
          .card-value { font-size: 24px; font-weight: 700; margin-top: 4px; }
          table { width: 100%; border-collapse: collapse; margin-top: 15px; margin-bottom: 30px; font-size: 13px; }
          th { text-align: left; background: #f5f5f5; padding: 10px; border-bottom: 1px solid #ddd; font-weight: 600; }
          td { padding: 10px; border-bottom: 1px solid #eee; }
          .text-right { text-align: right; }
          .footer { font-size: 11px; color: #888; text-align: center; border-top: 1px solid #eee; padding-top: 20px; margin-top: 40px; }
        </style>
      </head>
      <body>
        <div class="header">
          <div>
            <div class="title">KURO EXPENSE</div>
            <div class="subtitle">Personal Expenses Tracking and Analysis System</div>
          </div>
          <div style="text-align: right;">
            <div>Statement Date: ${new Date().toLocaleDateString()}</div>
            <div style="font-size: 12px; color: #777;">Currency: ${currency}</div>
          </div>
        </div>

        <div class="grid">
          <div class="card">
            <div class="card-label">Total Income</div>
            <div class="card-value" style="color: #15803d;">${currency}${totalIncome.toLocaleString()}</div>
          </div>
          <div class="card">
            <div class="card-label">Total Expenses</div>
            <div class="card-value">${currency}${totalExpenses.toLocaleString()}</div>
          </div>
          <div class="card">
            <div class="card-label">Net Balance</div>
            <div class="card-value" style="color: ${balance >= 0 ? '#111' : '#dc2626'};">${currency}${balance.toLocaleString()}</div>
          </div>
        </div>

        <h3>Category Spending Breakdown</h3>
        <table>
          <thead>
            <tr>
              <th>Category</th>
              <th class="text-right">Amount (${currency})</th>
              <th class="text-right">Share (%)</th>
            </tr>
          </thead>
          <tbody>
            ${Object.entries(categoryBreakdown)
              .sort((a, b) => b[1] - a[1])
              .map(
                ([cat, amt]) => `
              <tr>
                <td><strong>${cat}</strong></td>
                <td class="text-right">${currency}${amt.toLocaleString()}</td>
                <td class="text-right">${totalExpenses > 0 ? Math.round((amt / totalExpenses) * 100) : 0}%</td>
              </tr>
            `
              )
              .join('')}
          </tbody>
        </table>

        <h3>Recent Expense Transactions</h3>
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Description</th>
              <th>Category</th>
              <th>Payment Method</th>
              <th class="text-right">Amount (${currency})</th>
            </tr>
          </thead>
          <tbody>
            ${expenses
              .slice(0, 30)
              .map(
                e => `
              <tr>
                <td>${e.date}</td>
                <td>${e.description}</td>
                <td>${e.category}</td>
                <td>${e.paymentMethod}</td>
                <td class="text-right" style="font-weight: 600;">${currency}${e.amount.toLocaleString()}</td>
              </tr>
            `
              )
              .join('')}
          </tbody>
        </table>

        <div class="footer">
          Generated automatically by Kuro Expense • Personal Financial Management System
        </div>
      </body>
    </html>
  `;

  printWindow.document.write(html);
  printWindow.document.close();
  printWindow.focus();
  setTimeout(() => {
    printWindow.print();
  }, 300);
}

function downloadBlob(content: string, type: string, filename: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
