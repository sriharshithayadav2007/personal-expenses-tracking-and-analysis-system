import React, { useState, useEffect } from 'react';
import { X, PieChart, ShieldAlert } from 'lucide-react';
import { ExpenseCategory, EXPENSE_CATEGORIES, Budget } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface BudgetModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (category: ExpenseCategory, limit: number) => Promise<void>;
  existingBudgets: Budget[];
  defaultCategory?: ExpenseCategory;
}

export const BudgetModal: React.FC<BudgetModalProps> = ({
  isOpen,
  onClose,
  onSave,
  existingBudgets,
  defaultCategory = 'Food',
}) => {
  const { currency } = useAuth();

  const [category, setCategory] = useState<ExpenseCategory>(defaultCategory);
  const [limit, setLimit] = useState<string>('5000');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    setCategory(defaultCategory);
    const found = existingBudgets.find(b => b.category === defaultCategory);
    if (found) {
      setLimit(found.limit.toString());
    } else {
      setLimit('5000');
    }
    setError('');
  }, [defaultCategory, existingBudgets, isOpen]);

  const handleCategoryChange = (cat: ExpenseCategory) => {
    setCategory(cat);
    const found = existingBudgets.find(b => b.category === cat);
    if (found) {
      setLimit(found.limit.toString());
    }
  };

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const numLimit = parseFloat(limit);
    if (isNaN(numLimit) || numLimit <= 0) {
      setError('Please enter a valid monthly limit greater than zero.');
      return;
    }

    try {
      setIsSubmitting(true);
      setError('');
      await onSave(category, numLimit);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save budget');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in">
      <div className="relative w-full max-w-md rounded-2xl border border-neutral-800 bg-neutral-950 p-6 shadow-2xl">
        <div className="flex items-center justify-between pb-4 border-b border-neutral-900">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-white text-black font-bold">
              <PieChart className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Set Category Budget</h2>
              <p className="text-xs text-neutral-400">Manage monthly expense thresholds</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-neutral-400 hover:bg-neutral-900 hover:text-white transition-colors"
            aria-label="Close modal"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {error && (
          <div className="mt-4 rounded-xl border border-rose-900/50 bg-rose-950/30 p-3 text-xs text-rose-300">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
              Expense Category
            </label>
            <select
              value={category}
              onChange={e => handleCategoryChange(e.target.value as ExpenseCategory)}
              className="w-full rounded-xl border border-neutral-800 bg-neutral-900/80 px-3.5 py-2.5 text-xs text-white focus:border-white focus:outline-none focus:ring-1 focus:ring-white transition-all"
            >
              {EXPENSE_CATEGORIES.map(cat => (
                <option key={cat} value={cat} className="bg-neutral-950 text-white">
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
              Monthly Budget Cap ({currency}) *
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-mono text-base font-bold text-neutral-400">
                {currency}
              </span>
              <input
                type="number"
                step="any"
                required
                placeholder="5000"
                value={limit}
                onChange={e => setLimit(e.target.value)}
                className="w-full rounded-xl border border-neutral-800 bg-neutral-900/80 py-2.5 pl-9 pr-4 font-mono text-base font-bold text-white placeholder-neutral-600 focus:border-white focus:outline-none focus:ring-1 focus:ring-white transition-all"
              />
            </div>
            <p className="mt-1.5 text-[11px] text-neutral-500">
              You will receive an amber warning alert at 80% and a red banner if exceeded.
            </p>
          </div>

          <div className="mt-6 flex items-center justify-end gap-3 pt-3 border-t border-neutral-900">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-neutral-800 px-4 py-2.5 text-xs font-medium text-neutral-400 hover:bg-neutral-900 hover:text-white transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="rounded-xl bg-white px-5 py-2.5 text-xs font-bold text-black hover:bg-neutral-200 active:scale-95 disabled:opacity-50 transition-all shadow-md"
            >
              {isSubmitting ? 'Saving...' : 'Set Budget'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
