import React, { useState } from 'react';
import {
  Settings,
  Moon,
  Coins,
  User,
  KeyRound,
  Trash2,
  LogOut,
  Shield,
  CheckCircle,
  AlertTriangle,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useExpense } from '../../context/ExpenseContext';
import { SUPPORTED_CURRENCIES } from '../../types';

interface SettingsViewProps {
  onOpenAuth: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onOpenAuth }) => {
  const {
    currentUser,
    userProfile,
    isGuest,
    currency,
    setCurrency,
    sendPasswordReset,
    logout,
  } = useAuth();

  const { resetFilters } = useExpense();

  const [passwordSent, setPasswordSent] = useState(false);
  const [resetConfirm, setResetConfirm] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');

  const handlePasswordReset = async () => {
    if (!currentUser?.email) {
      setStatusMsg('Please sign in with email to request password changes.');
      return;
    }
    try {
      await sendPasswordReset(currentUser.email);
      setPasswordSent(true);
      setStatusMsg(`Password reset instructions sent to ${currentUser.email}`);
    } catch (e: any) {
      setStatusMsg(e.message || 'Error sending password reset');
    }
  };

  const handleResetData = () => {
    localStorage.removeItem('kuro_expenses');
    localStorage.removeItem('kuro_incomes');
    localStorage.removeItem('kuro_budgets');
    localStorage.removeItem('kuro_profile');
    window.location.reload();
  };

  return (
    <div className="max-w-4xl space-y-6">
      {/* Header bar */}
      <div>
        <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white font-['Space_Grotesk']">
          Settings & Account
        </h1>
        <p className="text-xs text-neutral-400">
          Configure financial preferences, security, currency, and local cache
        </p>
      </div>

      {statusMsg && (
        <div className="flex items-center gap-2 rounded-2xl border border-neutral-800 bg-neutral-900/80 p-3.5 text-xs text-neutral-200">
          <CheckCircle className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>{statusMsg}</span>
        </div>
      )}

      {/* Currency & Localization Settings */}
      <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-6 backdrop-blur-xl space-y-4">
        <div className="flex items-center gap-2.5 pb-3 border-b border-neutral-900">
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-white text-black font-bold">
            <Coins className="h-4 w-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white">Default Currency</h2>
            <p className="text-xs text-neutral-400">Applies across all charts, budgets, and balance tabs</p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {SUPPORTED_CURRENCIES.map(curr => {
            const isSelected = currency === curr.symbol;
            return (
              <button
                key={curr.code}
                onClick={() => setCurrency(curr.symbol)}
                className={`flex items-center justify-between rounded-xl border p-3 text-xs transition-all ${
                  isSelected
                    ? 'border-white bg-white text-black font-bold shadow-md'
                    : 'border-neutral-800 bg-neutral-900/60 text-neutral-300 hover:border-neutral-700 hover:text-white'
                }`}
              >
                <span>{curr.name}</span>
                <span className="font-mono">{curr.symbol}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* UI & Theme Discipline */}
      <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-6 backdrop-blur-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-neutral-900 text-white font-bold">
              <Moon className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Theme Architecture</h2>
              <p className="text-xs text-neutral-400">Pure black (#000000) default monochrome fintech styling</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="rounded-full border border-neutral-800 bg-neutral-900 px-3 py-1 text-xs font-semibold text-white">
              Dark Mode (Enforced)
            </span>
          </div>
        </div>
      </div>

      {/* Profile & Authentication Management */}
      <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-6 backdrop-blur-xl space-y-5">
        <div className="flex items-center gap-2.5 pb-3 border-b border-neutral-900">
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-neutral-900 text-white font-bold">
            <User className="h-4 w-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white">User Profile & Identity</h2>
            <p className="text-xs text-neutral-400">Firebase Authentication credentials & session</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="rounded-xl border border-neutral-800/80 bg-neutral-900/40 p-4">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-neutral-500">
              Display Name
            </span>
            <div className="mt-1 text-sm font-bold text-white">
              {userProfile?.name || 'Guest User'}
            </div>
          </div>

          <div className="rounded-xl border border-neutral-800/80 bg-neutral-900/40 p-4">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-neutral-500">
              Account Email
            </span>
            <div className="mt-1 text-sm font-mono text-neutral-300">
              {currentUser?.email || (isGuest ? 'guest.mode@kuro.internal' : 'No email attached')}
            </div>
          </div>
        </div>

        {/* Password reset & account actions */}
        <div className="pt-2 flex flex-wrap items-center gap-3">
          {currentUser && !isGuest ? (
            <button
              onClick={handlePasswordReset}
              className="flex items-center gap-1.5 rounded-xl border border-neutral-800 bg-neutral-900 px-4 py-2 text-xs font-semibold text-white hover:border-neutral-700 hover:bg-neutral-800 active:scale-95 transition-all"
            >
              <KeyRound className="h-3.5 w-3.5 text-neutral-400" />
              <span>Change Password via Email</span>
            </button>
          ) : (
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 rounded-xl bg-white px-4 py-2 text-xs font-bold text-black hover:bg-neutral-200 active:scale-95 transition-all"
            >
              <Shield className="h-3.5 w-3.5" />
              <span>Sign In with Firebase</span>
            </button>
          )}

          {currentUser && (
            <button
              onClick={logout}
              className="flex items-center gap-1.5 rounded-xl border border-rose-950/80 bg-rose-950/30 px-4 py-2 text-xs font-semibold text-rose-300 hover:bg-rose-950/60 active:scale-95 transition-all"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span>Log Out</span>
            </button>
          )}
        </div>
      </div>

      {/* Danger Zone: Reset Application Data */}
      <div className="rounded-2xl border border-rose-900/40 bg-rose-950/10 p-6 backdrop-blur-xl space-y-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-rose-400 mt-0.5 shrink-0" />
          <div className="flex-1">
            <h2 className="text-sm font-bold text-white">Reset Local Workspace Data</h2>
            <p className="mt-1 text-xs text-neutral-400 leading-relaxed">
              Clear your locally cached transactions, seed entries, and preferences. This will restore the
              initial template state.
            </p>

            {resetConfirm ? (
              <div className="mt-4 flex items-center gap-3">
                <button
                  onClick={handleResetData}
                  className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-700 active:scale-95"
                >
                  Yes, confirm reset
                </button>
                <button
                  onClick={() => setResetConfirm(false)}
                  className="rounded-xl border border-neutral-800 bg-neutral-900 px-3 py-2 text-xs text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                onClick={() => setResetConfirm(true)}
                className="mt-4 flex items-center gap-1.5 rounded-xl border border-rose-900/60 bg-neutral-900 px-3.5 py-2 text-xs font-semibold text-rose-300 hover:bg-rose-900/30 transition-all"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Reset Application Cache</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
