#!/usr/bin/env bash
set -e

# Kuro Expense - GitHub Push Helper Script
echo "=================================================="
echo " Kuro Expense - Push to GitHub Repository"
echo "=================================================="

if [ -z "$1" ]; then
  echo "Usage: ./push-to-github.sh <GITHUB_REPO_URL>"
  echo "Example:"
  echo "  ./push-to-github.sh https://github.com/govinduvishnu05/kuro-expense.git"
  echo "Or with a Personal Access Token (PAT):"
  echo "  ./push-to-github.sh https://<YOUR_GITHUB_TOKEN>@github.com/govinduvishnu05/kuro-expense.git"
  exit 1
fi

REPO_URL="$1"

# Check if origin already exists
if git remote | grep -q "^origin$"; then
  echo "Updating existing 'origin' remote to $REPO_URL..."
  git remote set-url origin "$REPO_URL"
else
  echo "Adding 'origin' remote: $REPO_URL..."
  git remote add origin "$REPO_URL"
fi

echo "Pushing 'main' branch to remote origin..."
git push -u origin main

echo ""
echo "Successfully pushed Kuro Expense to GitHub!"
echo "Repository: $REPO_URL"
echo "=================================================="
