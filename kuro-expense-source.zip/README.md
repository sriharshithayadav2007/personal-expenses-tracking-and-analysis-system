# KURO — Personal Expenses Tracking & Analysis System

> A minimalist, production-ready fintech web application engineered with an ultra-clean monochrome aesthetic, real-time Cloud Firestore synchronization, Gemini 3.8 Flash AI spending audits, and comprehensive financial reporting.

---

## Overview

**Kuro Expense** is designed for modern financial tracking with high data density, zero-clutter typography, and instant feedback. Built with React 19, TypeScript, Tailwind CSS v4, Express, and Firebase.

### Key Capabilities
- **Monochrome UI**: Pure black (`#000000`) background, subtle neutral gray accents, and responsive layout across desktop and mobile.
- **Real-Time Data Sync**: Powered by Google Cloud Firestore with real-time websocket synchronization (`onSnapshot`) and offline persistence.
- **AI-Powered Financial Insights**: Server-side Gemini 3.8 Flash (`@google/genai`) neural engine that detects abnormal spend spikes, predicts end-of-month cash flow, and identifies recurring subscription leaks.
- **Comprehensive Budgeting**: Category-level budgets with dynamic progress tracking, 80% cautionary threshold notifications, and 100% budget breach alerts.
- **Multi-Format Exports**: 1-click export to printable PDF statements, CSV, dual-sheet Excel (`.xls`), and machine-readable JSON backups.
- **System Architecture Whitepapers**: Pre-compiled technical whitepapers in PDF format covering the Frontend Architecture and Backend & Database Schema.

---

## Tech Stack

| Layer | Technologies |
| :--- | :--- |
| **Frontend** | React 19, TypeScript, Tailwind CSS v4, Lucide React, Framer Motion |
| **Data Visualization** | Recharts (Area, Donut, Bar charts with monochrome theming) |
| **Backend & API** | Node.js, Express, Vite Middleware, `@google/genai` TypeScript SDK |
| **Authentication & Database** | Firebase Authentication (Email/Password & Google Sign-In), Cloud Firestore |
| **Testing & Quality** | `node:test` unit testing suite, TypeScript compiler (`tsc --noEmit`) |

---

## Project Structure

```
├── public/
│   ├── docs/                     # Interactive HTML architecture whitepapers
│   └── downloads/                # Pre-rendered PDF specifications
├── server/
│   └── geminiService.ts          # Server-side Gemini 3.8 Flash neural financial auditor
├── src/
│   ├── components/
│   │   ├── modals/               # Add/Edit Expense, Income, Budget, Auth dialogs
│   │   ├── views/                # Dashboard, Expenses, Income, Budgets, Analytics, Reports, Settings
│   │   ├── LandingPage.tsx       # Modern product landing page
│   │   ├── Navbar.tsx            # Global topbar with live balance & actions
│   │   ├── Sidebar.tsx           # Desktop sidebar navigation
│   │   └── MobileNav.tsx         # Mobile bottom navigation bar
│   ├── context/
│   │   ├── AuthContext.tsx       # Authentication state & user preferences
│   │   └── ExpenseContext.tsx    # Real-time Firestore sync & cash flow calculations
│   ├── types/                    # Domain data models & TypeScript definitions
│   └── utils/
│       ├── calculations.ts       # Pure financial calculation helpers
│       ├── calculations.test.ts  # Test suite for financial metrics
│       └── export.ts             # Export pipelines (PDF, CSV, Excel, JSON)
├── firestore.rules               # Zero-Trust Attribute-Based Access Control (ABAC) rules
├── firebase-blueprint.json       # Database schema and index definitions
├── server.ts                     # Express server & API routes
└── vite.config.ts                # Vite configuration
```

---

## Getting Started

### Prerequisites
- [Node.js](https://nodejs.org/) (version 20+ recommended)
- npm or bun

### 1. Clone the repository
```bash
git clone https://github.com/<your-username>/kuro-expense.git
cd kuro-expense
```

### 2. Install dependencies
```bash
npm install
```

### 3. Environment Configuration
Create a `.env` file in the root directory:
```env
# Gemini API Key for server-side AI spending audits
GEMINI_API_KEY="your-gemini-api-key"

# Port (default: 3000)
PORT=3000
```

### 4. Run Development Server
```bash
npm run dev
```
Open your browser at `http://localhost:3000`.

### 5. Run Unit Tests
```bash
npm test
```

### 6. Build for Production
```bash
npm run build
npm start
```

---

## Security & Database Rules

The project implements a strict Zero-Trust Attribute-Based Access Control (ABAC) security model in `firestore.rules`:
- Default-deny catch-all rule for unauthorized paths.
- Each user can only read, create, update, and delete their own records (`request.auth.uid == resource.data.userId`).
- Strict payload validation preventing negative amounts and malformed entries.

---

## License

Apache-2.0
