import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import {
  Expense,
  Income,
  Budget,
  ExpenseCategory,
  PaymentMethod,
  IncomeSource,
  AiInsightsResponse,
} from '../types';
import { INITIAL_EXPENSES, INITIAL_INCOMES, INITIAL_BUDGETS } from '../data/seedData';
import { useAuth } from './AuthContext';
import {
  db,
  handleFirestoreError,
  OperationType,
} from '../lib/firebase';
import {
  collection,
  query,
  where,
  onSnapshot,
  doc,
  setDoc,
  deleteDoc,
} from 'firebase/firestore';
import { calculateFinancialSummary, calculateCategoryBreakdown } from '../utils/calculations';

export interface FilterState {
  searchQuery: string;
  category: string;
  paymentMethod: string;
  dateRange: 'all' | 'this-month' | 'last-month' | 'this-week' | 'custom';
  startDate: string;
  endDate: string;
  minAmount: number;
  maxAmount: number;
}

export interface NotificationItem {
  id: string;
  type: 'warning' | 'danger' | 'info' | 'success';
  title: string;
  message: string;
  time: string;
  read: boolean;
}

interface ExpenseContextType {
  expenses: Expense[];
  incomes: Income[];
  budgets: Budget[];
  filteredExpenses: Expense[];
  filterState: FilterState;
  setFilterState: React.Dispatch<React.SetStateAction<FilterState>>;
  resetFilters: () => void;
  // Financial metrics
  totalIncome: number;
  totalExpenses: number;
  balance: number;
  savingsRate: number;
  categoryBreakdown: Record<string, number>;
  // Actions
  addExpense: (expense: Omit<Expense, 'id' | 'userId' | 'createdAt'>) => Promise<void>;
  editExpense: (id: string, updates: Partial<Expense>) => Promise<void>;
  deleteExpense: (id: string) => Promise<void>;
  addIncome: (income: Omit<Income, 'id' | 'userId' | 'createdAt'>) => Promise<void>;
  editIncome: (id: string, updates: Partial<Income>) => Promise<void>;
  deleteIncome: (id: string) => Promise<void>;
  setCategoryBudget: (category: ExpenseCategory, limit: number) => Promise<void>;
  deleteBudget: (id: string) => Promise<void>;
  // AI Insights
  aiInsights: AiInsightsResponse | null;
  loadingAi: boolean;
  fetchAiInsights: (force?: boolean) => Promise<void>;
  // Notifications
  notifications: NotificationItem[];
  markNotificationAsRead: (id: string) => void;
  clearAllNotifications: () => void;
}

const ExpenseContext = createContext<ExpenseContextType | undefined>(undefined);

const DEFAULT_FILTERS: FilterState = {
  searchQuery: '',
  category: 'All',
  paymentMethod: 'All',
  dateRange: 'all',
  startDate: '',
  endDate: '',
  minAmount: 0,
  maxAmount: 100000,
};

export const ExpenseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, isGuest, currency } = useAuth();

  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem('kuro_expenses');
    return saved ? JSON.parse(saved) : INITIAL_EXPENSES;
  });

  const [incomes, setIncomes] = useState<Income[]>(() => {
    const saved = localStorage.getItem('kuro_incomes');
    return saved ? JSON.parse(saved) : INITIAL_INCOMES;
  });

  const [budgets, setBudgets] = useState<Budget[]>(() => {
    const saved = localStorage.getItem('kuro_budgets');
    return saved ? JSON.parse(saved) : INITIAL_BUDGETS;
  });

  const [filterState, setFilterState] = useState<FilterState>(DEFAULT_FILTERS);
  const [aiInsights, setAiInsights] = useState<AiInsightsResponse | null>(null);
  const [loadingAi, setLoadingAi] = useState<boolean>(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  // Real-time Firestore sync when user is authenticated
  useEffect(() => {
    if (!currentUser || isGuest) {
      // In guest mode, persist to localStorage
      localStorage.setItem('kuro_expenses', JSON.stringify(expenses));
      localStorage.setItem('kuro_incomes', JSON.stringify(incomes));
      localStorage.setItem('kuro_budgets', JSON.stringify(budgets));
      return;
    }

    const uid = currentUser.uid;

    // Listen to Expenses
    const expQuery = query(collection(db, 'expenses'), where('userId', '==', uid));
    const unsubscribeExpenses = onSnapshot(
      expQuery,
      snapshot => {
        const list: Expense[] = [];
        snapshot.forEach(docSnap => {
          const d = docSnap.data();
          list.push({
            id: docSnap.id,
            userId: d.userId,
            amount: Number(d.amount),
            category: d.category,
            description: d.description,
            paymentMethod: d.paymentMethod,
            date: d.date,
            notes: d.notes,
            createdAt: d.createdAt,
          });
        });
        // Sort descending by date
        list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        setExpenses(list);
      },
      error => {
        handleFirestoreError(error, OperationType.GET, 'expenses');
      }
    );

    // Listen to Incomes
    const incQuery = query(collection(db, 'income'), where('userId', '==', uid));
    const unsubscribeIncomes = onSnapshot(
      incQuery,
      snapshot => {
        const list: Income[] = [];
        snapshot.forEach(docSnap => {
          const d = docSnap.data();
          list.push({
            id: docSnap.id,
            userId: d.userId,
            amount: Number(d.amount),
            source: d.source,
            date: d.date,
            notes: d.notes,
            createdAt: d.createdAt,
          });
        });
        list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        setIncomes(list);
      },
      error => {
        handleFirestoreError(error, OperationType.GET, 'income');
      }
    );

    // Listen to Budgets
    const budQuery = query(collection(db, 'budgets'), where('userId', '==', uid));
    const unsubscribeBudgets = onSnapshot(
      budQuery,
      snapshot => {
        const list: Budget[] = [];
        snapshot.forEach(docSnap => {
          const d = docSnap.data();
          list.push({
            id: docSnap.id,
            userId: d.userId,
            category: d.category,
            limit: Number(d.limit),
            month: Number(d.month),
            year: Number(d.year),
            createdAt: d.createdAt,
          });
        });
        setBudgets(list);
      },
      error => {
        handleFirestoreError(error, OperationType.GET, 'budgets');
      }
    );

    return () => {
      unsubscribeExpenses();
      unsubscribeIncomes();
      unsubscribeBudgets();
    };
  }, [currentUser, isGuest]);

  // Derived financial summary
  const { totalIncome, totalExpenses, balance, savingsRate } = useMemo(() => {
    return calculateFinancialSummary(incomes, expenses);
  }, [incomes, expenses]);

  const categoryBreakdown = useMemo(() => {
    return calculateCategoryBreakdown(expenses);
  }, [expenses]);

  // Check budget limits & generate notifications
  useEffect(() => {
    const newNotifications: NotificationItem[] = [];
    const now = new Date();
    const currentMonth = now.getMonth() + 1;
    const currentYear = now.getFullYear();

    // Filter current month expenses for budget tracking
    const currentMonthExpenses = expenses.filter(e => {
      if (!e.date) return false;
      const d = new Date(e.date);
      return d.getMonth() + 1 === currentMonth && d.getFullYear() === currentYear;
    });

    const monthCategorySpend = calculateCategoryBreakdown(currentMonthExpenses);

    budgets.forEach(b => {
      const spent = monthCategorySpend[b.category] || 0;
      const percentage = Math.round((spent / (b.limit || 1)) * 100);

      if (percentage >= 100) {
        newNotifications.push({
          id: `budget-exceeded-${b.category}`,
          type: 'danger',
          title: `Budget Exceeded: ${b.category}`,
          message: `You've spent ${currency}${spent.toLocaleString()} which exceeds your ${currency}${b.limit.toLocaleString()} budget by ${percentage - 100}%.`,
          time: 'Just now',
          read: false,
        });
      } else if (percentage >= 80) {
        newNotifications.push({
          id: `budget-warn-${b.category}`,
          type: 'warning',
          title: `Budget Alert: ${b.category} at ${percentage}%`,
          message: `You've used ${currency}${spent.toLocaleString()} of your ${currency}${b.limit.toLocaleString()} monthly budget.`,
          time: 'Attention needed',
          read: false,
        });
      }
    });

    // Add sample bill reminder
    newNotifications.push({
      id: 'bill-reminder-cloud',
      type: 'info',
      title: 'Upcoming Bill: Cloud Infrastructure',
      message: `${currency}2,150 is scheduled for auto-debit on the 28th.`,
      time: 'Upcoming in 4 days',
      read: false,
    });

    setNotifications(newNotifications);
  }, [expenses, budgets, currency]);

  // Filtered expenses based on search & multi-filtering
  const filteredExpenses = useMemo(() => {
    return expenses.filter(item => {
      // Search keyword
      if (filterState.searchQuery.trim()) {
        const query = filterState.searchQuery.toLowerCase();
        const matchDesc = item.description.toLowerCase().includes(query);
        const matchCat = item.category.toLowerCase().includes(query);
        const matchNotes = (item.notes || '').toLowerCase().includes(query);
        const matchMethod = item.paymentMethod.toLowerCase().includes(query);
        if (!matchDesc && !matchCat && !matchNotes && !matchMethod) return false;
      }

      // Category filter
      if (filterState.category !== 'All' && item.category !== filterState.category) {
        return false;
      }

      // Payment Method filter
      if (filterState.paymentMethod !== 'All' && item.paymentMethod !== filterState.paymentMethod) {
        return false;
      }

      // Amount filter
      if (item.amount < filterState.minAmount) return false;
      if (filterState.maxAmount > 0 && item.amount > filterState.maxAmount) return false;

      // Date range filter
      if (filterState.dateRange !== 'all') {
        const itemDate = new Date(item.date);
        const now = new Date();

        if (filterState.dateRange === 'this-month') {
          if (itemDate.getMonth() !== now.getMonth() || itemDate.getFullYear() !== now.getFullYear()) {
            return false;
          }
        } else if (filterState.dateRange === 'last-month') {
          const lastMonth = now.getMonth() === 0 ? 11 : now.getMonth() - 1;
          const lastMonthYear = now.getMonth() === 0 ? now.getFullYear() - 1 : now.getFullYear();
          if (itemDate.getMonth() !== lastMonth || itemDate.getFullYear() !== lastMonthYear) {
            return false;
          }
        } else if (filterState.dateRange === 'this-week') {
          const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
          if (itemDate < weekAgo) return false;
        } else if (filterState.dateRange === 'custom') {
          if (filterState.startDate && item.date < filterState.startDate) return false;
          if (filterState.endDate && item.date > filterState.endDate) return false;
        }
      }

      return true;
    });
  }, [expenses, filterState]);

  const resetFilters = () => setFilterState(DEFAULT_FILTERS);

  // Expense CRUD
  const addExpense = async (data: Omit<Expense, 'id' | 'userId' | 'createdAt'>) => {
    const id = 'exp-' + Date.now();
    const uid = currentUser?.uid || 'guest-user-001';
    const newExp: Expense = {
      ...data,
      id,
      userId: uid,
      createdAt: new Date().toISOString(),
    };

    if (currentUser && !isGuest) {
      try {
        await setDoc(doc(db, 'expenses', id), newExp);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, 'expenses');
      }
    } else {
      setExpenses(prev => [newExp, ...prev]);
    }
  };

  const editExpense = async (id: string, updates: Partial<Expense>) => {
    if (currentUser && !isGuest) {
      try {
        await setDoc(doc(db, 'expenses', id), updates, { merge: true });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, 'expenses');
      }
    } else {
      setExpenses(prev => prev.map(e => (e.id === id ? { ...e, ...updates } : e)));
    }
  };

  const deleteExpense = async (id: string) => {
    if (currentUser && !isGuest) {
      try {
        await deleteDoc(doc(db, 'expenses', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, 'expenses');
      }
    } else {
      setExpenses(prev => prev.filter(e => e.id !== id));
    }
  };

  // Income CRUD
  const addIncome = async (data: Omit<Income, 'id' | 'userId' | 'createdAt'>) => {
    const id = 'inc-' + Date.now();
    const uid = currentUser?.uid || 'guest-user-001';
    const newInc: Income = {
      ...data,
      id,
      userId: uid,
      createdAt: new Date().toISOString(),
    };

    if (currentUser && !isGuest) {
      try {
        await setDoc(doc(db, 'income', id), newInc);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, 'income');
      }
    } else {
      setIncomes(prev => [newInc, ...prev]);
    }
  };

  const editIncome = async (id: string, updates: Partial<Income>) => {
    if (currentUser && !isGuest) {
      try {
        await setDoc(doc(db, 'income', id), updates, { merge: true });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, 'income');
      }
    } else {
      setIncomes(prev => prev.map(i => (i.id === id ? { ...i, ...updates } : i)));
    }
  };

  const deleteIncome = async (id: string) => {
    if (currentUser && !isGuest) {
      try {
        await deleteDoc(doc(db, 'income', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, 'income');
      }
    } else {
      setIncomes(prev => prev.filter(i => i.id !== id));
    }
  };

  // Budget CRUD
  const setCategoryBudget = async (category: ExpenseCategory, limit: number) => {
    const existing = budgets.find(b => b.category === category);
    const now = new Date();
    const month = now.getMonth() + 1;
    const year = now.getFullYear();
    const uid = currentUser?.uid || 'guest-user-001';
    const id = existing ? existing.id : 'bud-' + Date.now();

    const budgetDoc: Budget = {
      id,
      userId: uid,
      category,
      limit,
      month,
      year,
      createdAt: existing ? existing.createdAt : new Date().toISOString(),
    };

    if (currentUser && !isGuest) {
      try {
        await setDoc(doc(db, 'budgets', id), budgetDoc);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, 'budgets');
      }
    } else {
      setBudgets(prev => {
        const filtered = prev.filter(b => b.category !== category);
        return [...filtered, budgetDoc];
      });
    }
  };

  const deleteBudget = async (id: string) => {
    if (currentUser && !isGuest) {
      try {
        await deleteDoc(doc(db, 'budgets', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, 'budgets');
      }
    } else {
      setBudgets(prev => prev.filter(b => b.id !== id));
    }
  };

  // Fetch AI Insights
  const fetchAiInsights = useCallback(
    async (force: boolean = false) => {
      if (aiInsights && !force) return;

      setLoadingAi(true);
      try {
        const response = await fetch('/api/ai-insights', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            expenses: expenses.map(e => ({
              amount: e.amount,
              category: e.category,
              description: e.description,
              date: e.date,
              paymentMethod: e.paymentMethod,
            })),
            incomes: incomes.map(i => ({
              amount: i.amount,
              source: i.source,
              date: i.date,
            })),
            budgets: budgets.map(b => ({
              category: b.category,
              limit: b.limit,
            })),
            currency,
          }),
        });

        if (response.ok) {
          const data = await response.json();
          setAiInsights(data);
        } else {
          console.warn('AI insights API returned non-200');
        }
      } catch (err) {
        console.error('Error fetching AI insights:', err);
      } finally {
        setLoadingAi(false);
      }
    },
    [expenses, incomes, budgets, currency, aiInsights]
  );

  // Auto-fetch insights on initial load once
  useEffect(() => {
    if (!aiInsights) {
      fetchAiInsights();
    }
  }, [fetchAiInsights, aiInsights]);

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => (n.id === id ? { ...n, read: true } : n)));
  };

  const clearAllNotifications = () => {
    setNotifications([]);
  };

  return (
    <ExpenseContext.Provider
      value={{
        expenses,
        incomes,
        budgets,
        filteredExpenses,
        filterState,
        setFilterState,
        resetFilters,
        totalIncome,
        totalExpenses,
        balance,
        savingsRate,
        categoryBreakdown,
        addExpense,
        editExpense,
        deleteExpense,
        addIncome,
        editIncome,
        deleteIncome,
        setCategoryBudget,
        deleteBudget,
        aiInsights,
        loadingAi,
        fetchAiInsights,
        notifications,
        markNotificationAsRead,
        clearAllNotifications,
      }}
    >
      {children}
    </ExpenseContext.Provider>
  );
};

export const useExpense = () => {
  const context = useContext(ExpenseContext);
  if (!context) {
    throw new Error('useExpense must be used within an ExpenseProvider');
  }
  return context;
};
