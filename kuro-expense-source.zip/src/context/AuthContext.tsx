import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import {
  auth,
  db,
  loginWithGoogle,
  loginWithEmail,
  registerWithEmail,
  resetPassword,
  logOut,
  handleFirestoreError,
  OperationType,
} from '../lib/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { UserProfile, SUPPORTED_CURRENCIES } from '../types';

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  isGuest: boolean;
  currency: string;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  signUp: (email: string, pass: string, name?: string) => Promise<void>;
  sendPasswordReset: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  continueAsGuest: () => void;
  setCurrency: (symbol: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const GUEST_PROFILE: UserProfile = {
  uid: 'guest-user-001',
  name: 'Alex Rivera',
  email: 'alex.rivera@fintech.io',
  currency: '₹',
  createdAt: new Date().toISOString(),
  isGuest: true,
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('kuro_profile');
    return saved ? JSON.parse(saved) : GUEST_PROFILE;
  });
  const [isGuest, setIsGuest] = useState<boolean>(() => {
    return localStorage.getItem('kuro_is_guest') !== 'false';
  });
  const [currency, setCurrencyState] = useState<string>(() => {
    return localStorage.getItem('kuro_currency') || '₹';
  });
  const [loading, setLoading] = useState<boolean>(true);

  // Sync auth state
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async user => {
      if (user) {
        setCurrentUser(user);
        setIsGuest(false);
        localStorage.setItem('kuro_is_guest', 'false');

        // Fetch or create profile in Firestore
        try {
          const userDocRef = doc(db, 'users', user.uid);
          const snap = await getDoc(userDocRef);
          if (snap.exists()) {
            const data = snap.data();
            const prof: UserProfile = {
              uid: user.uid,
              name: data.name || user.displayName || 'Finance Pro',
              email: user.email || '',
              photoURL: user.photoURL || undefined,
              currency: data.currency || currency,
              createdAt: data.createdAt || new Date().toISOString(),
              isGuest: false,
            };
            setUserProfile(prof);
            if (data.currency) {
              setCurrencyState(data.currency);
              localStorage.setItem('kuro_currency', data.currency);
            }
          } else {
            const newProf: UserProfile = {
              uid: user.uid,
              name: user.displayName || user.email?.split('@')[0] || 'Finance Member',
              email: user.email || '',
              photoURL: user.photoURL || undefined,
              currency: currency,
              createdAt: new Date().toISOString(),
              isGuest: false,
            };
            await setDoc(userDocRef, {
              uid: newProf.uid,
              name: newProf.name,
              email: newProf.email,
              photoURL: newProf.photoURL || '',
              currency: newProf.currency,
              createdAt: newProf.createdAt,
            });
            setUserProfile(newProf);
          }
        } catch (err) {
          console.warn('Firestore profile fetch fallback:', err);
          // Fallback to local profile without failing login
          setUserProfile({
            uid: user.uid,
            name: user.displayName || user.email?.split('@')[0] || 'User',
            email: user.email || '',
            photoURL: user.photoURL || undefined,
            currency: currency,
            createdAt: new Date().toISOString(),
            isGuest: false,
          });
        }
      } else {
        setCurrentUser(null);
        if (!isGuest) {
          // If not in guest mode, user is signed out
          setUserProfile(null);
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [currency, isGuest]);

  const setCurrency = async (newCurrency: string) => {
    setCurrencyState(newCurrency);
    localStorage.setItem('kuro_currency', newCurrency);

    if (userProfile) {
      const updated = { ...userProfile, currency: newCurrency };
      setUserProfile(updated);
      localStorage.setItem('kuro_profile', JSON.stringify(updated));

      if (currentUser && !isGuest) {
        try {
          await setDoc(doc(db, 'users', currentUser.uid), { currency: newCurrency }, { merge: true });
        } catch (e) {
          console.warn('Could not sync currency to Firestore:', e);
        }
      }
    }
  };

  const handleSignInGoogle = async () => {
    const result = await loginWithGoogle();
    if (result.user) {
      setIsGuest(false);
      localStorage.setItem('kuro_is_guest', 'false');
    }
  };

  const handleSignInEmail = async (email: string, pass: string) => {
    const result = await loginWithEmail(email, pass);
    if (result.user) {
      setIsGuest(false);
      localStorage.setItem('kuro_is_guest', 'false');
    }
  };

  const handleSignUp = async (email: string, pass: string, name?: string) => {
    const result = await registerWithEmail(email, pass, name);
    if (result.user) {
      setIsGuest(false);
      localStorage.setItem('kuro_is_guest', 'false');
    }
  };

  const handleResetPassword = async (email: string) => {
    await resetPassword(email);
  };

  const handleLogout = async () => {
    await logOut();
    setCurrentUser(null);
    setUserProfile(null);
    setIsGuest(false);
    localStorage.setItem('kuro_is_guest', 'false');
    localStorage.removeItem('kuro_profile');
  };

  const continueAsGuest = () => {
    setIsGuest(true);
    localStorage.setItem('kuro_is_guest', 'true');
    setUserProfile(GUEST_PROFILE);
    localStorage.setItem('kuro_profile', JSON.stringify(GUEST_PROFILE));
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        isGuest,
        currency,
        loading,
        signInWithGoogle: handleSignInGoogle,
        signInWithEmail: handleSignInEmail,
        signUp: handleSignUp,
        sendPasswordReset: handleResetPassword,
        logout: handleLogout,
        continueAsGuest,
        setCurrency,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
