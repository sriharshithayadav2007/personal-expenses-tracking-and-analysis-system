/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ExpenseProvider, useExpense } from './context/ExpenseContext';
import { NavigationTab, Expense, Income, ExpenseCategory } from './types';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { MobileNav } from './components/MobileNav';
import { LandingPage } from './components/LandingPage';
import { DashboardView } from './components/views/DashboardView';
import { ExpensesView } from './components/views/ExpensesView';
import { IncomeView } from './components/views/IncomeView';
import { BudgetView } from './components/views/BudgetView';
import { AnalyticsView } from './components/views/AnalyticsView';
import { ReportsView } from './components/views/ReportsView';
import { SettingsView } from './components/views/SettingsView';
import { ExpenseModal } from './components/modals/ExpenseModal';
import { IncomeModal } from './components/modals/IncomeModal';
import { BudgetModal } from './components/modals/BudgetModal';
import { AuthModal } from './components/modals/AuthModal';

const MainAppContent: React.FC = () => {
  const { currentUser, isGuest } = useAuth();
  const { addExpense, editExpense, addIncome, editIncome, setCategoryBudget, budgets } = useExpense();

  const [activeTab, setActiveTab] = useState<NavigationTab>('dashboard');
  const [showLanding, setShowLanding] = useState<boolean>(false);

  // Modals state
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [expenseToEdit, setExpenseToEdit] = useState<Expense | null>(null);

  const [isIncomeModalOpen, setIsIncomeModalOpen] = useState(false);
  const [incomeToEdit, setIncomeToEdit] = useState<Income | null>(null);

  const [isBudgetModalOpen, setIsBudgetModalOpen] = useState(false);
  const [budgetCategoryToEdit, setBudgetCategoryToEdit] = useState<ExpenseCategory>('Food');

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // Expense Handlers
  const handleOpenAddExpense = () => {
    setExpenseToEdit(null);
    setIsExpenseModalOpen(true);
  };

  const handleEditExpense = (exp: Expense) => {
    setExpenseToEdit(exp);
    setIsExpenseModalOpen(true);
  };

  const handleSaveExpense = async (data: Omit<Expense, 'id' | 'userId' | 'createdAt'>) => {
    if (expenseToEdit) {
      await editExpense(expenseToEdit.id, data);
    } else {
      await addExpense(data);
    }
  };

  // Income Handlers
  const handleOpenAddIncome = () => {
    setIncomeToEdit(null);
    setIsIncomeModalOpen(true);
  };

  const handleEditIncome = (inc: Income) => {
    setIncomeToEdit(inc);
    setIsIncomeModalOpen(true);
  };

  const handleSaveIncome = async (data: Omit<Income, 'id' | 'userId' | 'createdAt'>) => {
    if (incomeToEdit) {
      await editIncome(incomeToEdit.id, data);
    } else {
      await addIncome(data);
    }
  };

  // Budget Handlers
  const handleOpenSetBudget = (category: ExpenseCategory = 'Food') => {
    setBudgetCategoryToEdit(category);
    setIsBudgetModalOpen(true);
  };

  const handleSaveBudget = async (category: ExpenseCategory, limit: number) => {
    await setCategoryBudget(category, limit);
  };

  return (
    <div className="min-h-screen bg-black text-white selection:bg-white selection:text-black flex flex-col font-sans">
      {/* Top Navbar */}
      <Navbar
        onOpenAddExpense={handleOpenAddExpense}
        onOpenAddIncome={handleOpenAddIncome}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        showLanding={showLanding}
        setShowLanding={setShowLanding}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {showLanding ? (
        <LandingPage
          onGetStarted={() => {
            setShowLanding(false);
            if (!currentUser && isGuest) {
              setIsAuthModalOpen(true);
            }
          }}
          onExploreDemo={() => {
            setShowLanding(false);
            setActiveTab('dashboard');
          }}
        />
      ) : (
        <div className="flex flex-1">
          {/* Desktop Left Sidebar */}
          <Sidebar
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            onOpenAddExpense={handleOpenAddExpense}
          />

          {/* Main Content Area */}
          <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full pb-24 lg:pb-12">
            {activeTab === 'dashboard' && (
              <DashboardView
                onOpenAddExpense={handleOpenAddExpense}
                onOpenAddIncome={handleOpenAddIncome}
                onEditExpense={handleEditExpense}
                setActiveTab={setActiveTab}
              />
            )}

            {activeTab === 'expenses' && (
              <ExpensesView
                onOpenAddExpense={handleOpenAddExpense}
                onEditExpense={handleEditExpense}
              />
            )}

            {activeTab === 'income' && (
              <IncomeView
                onOpenAddIncome={handleOpenAddIncome}
                onEditIncome={handleEditIncome}
              />
            )}

            {activeTab === 'budget' && (
              <BudgetView onOpenSetBudget={handleOpenSetBudget} />
            )}

            {activeTab === 'analytics' && <AnalyticsView />}

            {activeTab === 'reports' && <ReportsView />}

            {activeTab === 'settings' && (
              <SettingsView onOpenAuth={() => setIsAuthModalOpen(true)} />
            )}
          </main>

          {/* Mobile Bottom Navigation Bar & FAB */}
          <MobileNav
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            onOpenAddExpense={handleOpenAddExpense}
          />
        </div>
      )}

      {/* Modals */}
      <ExpenseModal
        isOpen={isExpenseModalOpen}
        onClose={() => setIsExpenseModalOpen(false)}
        onSave={handleSaveExpense}
        expenseToEdit={expenseToEdit}
      />

      <IncomeModal
        isOpen={isIncomeModalOpen}
        onClose={() => setIsIncomeModalOpen(false)}
        onSave={handleSaveIncome}
        incomeToEdit={incomeToEdit}
      />

      <BudgetModal
        isOpen={isBudgetModalOpen}
        onClose={() => setIsBudgetModalOpen(false)}
        onSave={handleSaveBudget}
        existingBudgets={budgets}
        defaultCategory={budgetCategoryToEdit}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <ExpenseProvider>
        <MainAppContent />
      </ExpenseProvider>
    </AuthProvider>
  );
}
