import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateFinancialSummary,
  calculateCategoryBreakdown,
  calculateBudgetStatus,
  findBiggestSpendingDay,
  calculatePercentageChange,
} from './calculations';

test('calculateFinancialSummary calculates balance and savings rate accurately', () => {
  const income = [{ amount: 50000 }, { amount: 15000 }];
  const expenses = [{ amount: 20000 }, { amount: 6000 }, { amount: 4000 }];

  const summary = calculateFinancialSummary(income, expenses);
  assert.equal(summary.totalIncome, 65000);
  assert.equal(summary.totalExpenses, 30000);
  assert.equal(summary.balance, 35000);
  assert.equal(summary.savingsRate, 54); // (35000 / 65000) * 100 ~ 53.84 -> 54%
});

test('calculateCategoryBreakdown sums spending by category', () => {
  const expenses = [
    { category: 'Food', amount: 1200 },
    { category: 'Transport', amount: 800 },
    { category: 'Food', amount: 500 },
    { category: 'Bills', amount: 3000 },
  ];

  const breakdown = calculateCategoryBreakdown(expenses);
  assert.equal(breakdown['Food'], 1700);
  assert.equal(breakdown['Transport'], 800);
  assert.equal(breakdown['Bills'], 3000);
});

test('calculateBudgetStatus triggers normal, warning at 80%, and exceeded at >=100%', () => {
  // Normal (50%)
  const normal = calculateBudgetStatus(5000, 2500);
  assert.equal(normal.status, 'normal');
  assert.equal(normal.percentage, 50);
  assert.equal(normal.remaining, 2500);

  // Warning (80%)
  const warning = calculateBudgetStatus(5000, 4100);
  assert.equal(warning.status, 'warning');
  assert.equal(warning.percentage, 82);
  assert.equal(warning.remaining, 900);

  // Exceeded (110%)
  const exceeded = calculateBudgetStatus(5000, 5500);
  assert.equal(exceeded.status, 'exceeded');
  assert.equal(exceeded.percentage, 110);
  assert.equal(exceeded.remaining, 0);
});

test('findBiggestSpendingDay correctly identifies day with highest spend', () => {
  const expenses = [
    { date: '2026-10-14', amount: 500 },
    { date: '2026-10-15', amount: 3200 },
    { date: '2026-10-15', amount: 1800 }, // Total 5000 on Oct 15
    { date: '2026-10-16', amount: 4500 },
  ];

  const topDay = findBiggestSpendingDay(expenses);
  assert.deepEqual(topDay, { date: '2026-10-15', amount: 5000 });
});

test('calculatePercentageChange calculates directional change correctly', () => {
  assert.equal(calculatePercentageChange(1350, 1000), 35); // 35% increase
  assert.equal(calculatePercentageChange(880, 1000), -12); // 12% decrease
  assert.equal(calculatePercentageChange(500, 0), 100);
});
