import React, { useState } from 'react';
import {
  ArrowRight,
  ShieldCheck,
  Sparkles,
  PieChart,
  BarChart3,
  Lock,
  ChevronDown,
  ChevronUp,
  Receipt,
  TrendingUp,
  CheckCircle2,
  Zap,
  Globe,
  Sliders,
  Download,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface LandingPageProps {
  onGetStarted: () => void;
  onExploreDemo: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onGetStarted,
  onExploreDemo,
}) => {
  const { currency } = useAuth();
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const faqs = [
    {
      q: 'How does Kuro Expense predict end-of-month spending?',
      a: 'Kuro integrates Gemini 3.8 Flash to analyze your day-by-day burn rate, categorical velocity, and recurring subscriptions to forecast month-end expenditure with exceptional precision.',
    },
    {
      q: 'How do the 80% and overspend budget alerts work?',
      a: 'Whenever your categorical spending crosses 80% of your allocated monthly cap, an ambient amber indicator triggers. If spending exceeds 100%, high-priority red alert banners prevent inadvertent wallet bleed.',
    },
    {
      q: 'Can I export my data for tax filing or accountant audits?',
      a: 'Yes. Export your complete financial logs in high-resolution printable PDF statements, multi-tab Excel workbooks (.xls), standard CSV files, or raw JSON database backups at any time with one click.',
    },
    {
      q: 'Is my financial data secured on Firebase?',
      a: 'All data is governed by zero-trust Firestore security rules. Strict Attribute-Based Access Control (ABAC) guarantees that only your verified user ID can read or mutate your records.',
    },
  ];

  const testimonials = [
    {
      quote:
        'Kuro’s pure black minimalist interface cuts out the useless fluff seen in other expense apps. The automatic 80% budget alerts alone saved me over ₹14,000 last month.',
      author: 'Vikramaditya S.',
      role: 'Principal Systems Architect',
      metric: 'Saved ₹14.2k/mo',
    },
    {
      quote:
        'The Gemini AI audit spotted three forgotten SaaS subscriptions that were silently draining my corporate card. The reports export seamlessly into Excel for my accountant.',
      author: 'Sophia Chen',
      role: 'Fintech Product Lead',
      metric: '3 Subscriptions Pruned',
    },
    {
      quote:
        'Clean typography, zero clutter, instant search, and real-time Firestore sync. It feels like software built for financial professionals.',
      author: 'Arjun Mehta',
      role: 'Founder & Venture Partner',
      metric: '44% Savings Rate',
    },
  ];

  return (
    <div className="bg-black text-white selection:bg-white selection:text-black min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 sm:pt-20 sm:pb-28 border-b border-neutral-900">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          {/* Subtle Tag pill */}
          <div className="inline-flex items-center gap-2 rounded-full border border-neutral-800 bg-neutral-950 px-3.5 py-1 text-xs text-neutral-300 mb-6 backdrop-blur-md">
            <span className="flex h-1.5 w-1.5 rounded-full bg-white animate-pulse" />
            <span className="font-medium tracking-wide">Next-Gen Autonomous Personal Finance</span>
          </div>

          {/* Reference Heading - Large Bold Monospace/Grotesk */}
          <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-black tracking-tighter text-white font-['Space_Grotesk'] leading-[1.05] uppercase">
            Personal Expenses
            <span className="block mt-1 text-neutral-400 font-extrabold text-3xl sm:text-5xl md:text-6xl lg:text-7xl">
              Tracking & Analysis System
            </span>
          </h1>

          <p className="mx-auto mt-6 max-w-2xl text-sm sm:text-base text-neutral-400 leading-relaxed font-normal">
            Take complete control over your cash flow. Real-time Firestore sync, dynamic Recharts analytics,
            strict 80% budget guardrails, and autonomous AI audits in a refined high-contrast monochrome design.
          </p>

          {/* Primary & Secondary Call To Actions */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3 sm:gap-4">
            <button
              onClick={onGetStarted}
              className="flex items-center gap-2 rounded-2xl bg-white px-7 py-3.5 text-sm font-bold text-black hover:bg-neutral-200 active:scale-95 transition-all shadow-xl shadow-white/5"
            >
              <span>Get Started</span>
              <ArrowRight className="h-4 w-4" />
            </button>
            <button
              onClick={onExploreDemo}
              className="flex items-center gap-2 rounded-2xl border border-neutral-800 bg-neutral-950 px-7 py-3.5 text-sm font-semibold text-white hover:border-neutral-700 hover:bg-neutral-900 active:scale-95 transition-all"
            >
              <Zap className="h-4 w-4 text-emerald-400" />
              <span>Explore Live Demo</span>
            </button>
            <a
              href="/downloads/kuro-expense-source.zip"
              download="kuro-expense-source.zip"
              className="flex items-center gap-2 rounded-2xl border border-neutral-700 bg-neutral-900 px-7 py-3.5 text-sm font-semibold text-white hover:border-white hover:bg-neutral-800 active:scale-95 transition-all shadow-md"
            >
              <Download className="h-4 w-4 text-white" />
              <span>Download ZIP (.zip)</span>
            </a>
          </div>

          {/* App Preview Mockup Container */}
          <div className="mt-14 sm:mt-20 mx-auto max-w-5xl rounded-3xl border border-neutral-800/80 bg-neutral-950/70 p-3 sm:p-5 shadow-2xl backdrop-blur-2xl">
            <div className="rounded-2xl border border-neutral-800 bg-black p-4 sm:p-6 text-left">
              {/* Window controls bar */}
              <div className="flex items-center justify-between pb-4 border-b border-neutral-900 mb-6">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-neutral-800" />
                  <div className="h-3 w-3 rounded-full bg-neutral-800" />
                  <div className="h-3 w-3 rounded-full bg-neutral-800" />
                </div>
                <div className="text-[11px] font-mono text-neutral-500">
                  kuro.app/dashboard • live preview
                </div>
                <div className="flex items-center gap-2 text-xs text-neutral-400">
                  <span className="h-2 w-2 rounded-full bg-emerald-500" />
                  <span>Synced</span>
                </div>
              </div>

              {/* Sample Metrics Mockup */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mb-6">
                <div className="rounded-xl border border-neutral-800/80 bg-neutral-950 p-3.5">
                  <span className="text-[10px] uppercase font-semibold text-neutral-400">
                    Total Balance
                  </span>
                  <div className="text-xl sm:text-2xl font-bold font-mono text-white mt-1">
                    {currency}78,450
                  </div>
                </div>
                <div className="rounded-xl border border-neutral-800/80 bg-neutral-950 p-3.5">
                  <span className="text-[10px] uppercase font-semibold text-neutral-400">
                    Total Income
                  </span>
                  <div className="text-xl sm:text-2xl font-bold font-mono text-emerald-400 mt-1">
                    +{currency}1,08,000
                  </div>
                </div>
                <div className="rounded-xl border border-neutral-800/80 bg-neutral-950 p-3.5">
                  <span className="text-[10px] uppercase font-semibold text-neutral-400">
                    Total Expenses
                  </span>
                  <div className="text-xl sm:text-2xl font-bold font-mono text-white mt-1">
                    -{currency}29,550
                  </div>
                </div>
                <div className="rounded-xl border border-neutral-800/80 bg-neutral-950 p-3.5">
                  <span className="text-[10px] uppercase font-semibold text-neutral-400">
                    Savings Rate
                  </span>
                  <div className="text-xl sm:text-2xl font-bold font-mono text-white mt-1">
                    72%
                  </div>
                </div>
              </div>

              {/* Sample Interactive Action Banner */}
              <div className="rounded-xl border border-neutral-800 bg-neutral-900/50 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <Sparkles className="h-5 w-5 text-white" />
                  <div>
                    <span className="text-xs font-bold text-white">
                      AI Audit Recommendation
                    </span>
                    <p className="text-[11px] text-neutral-400">
                      "Reducing weekend food delivery could boost monthly savings by {currency}1,800."
                    </p>
                  </div>
                </div>
                <button
                  onClick={onExploreDemo}
                  className="rounded-lg bg-white px-3.5 py-1.5 text-xs font-bold text-black hover:bg-neutral-200 transition-colors whitespace-nowrap self-start sm:self-auto"
                >
                  Open Dashboard
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Cards Section */}
      <section className="py-20 border-b border-neutral-900">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-500">
              Architected for Precision
            </span>
            <h2 className="mt-2 text-3xl sm:text-4xl font-extrabold tracking-tight text-white font-['Space_Grotesk']">
              Engineered with Fintech Rigor
            </h2>
            <p className="mt-3 text-xs sm:text-sm text-neutral-400">
              Every detail is calibrated for speed, clarity, and autonomous financial discipline.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Feature 1 */}
            <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-6 backdrop-blur-xl hover:border-neutral-700 transition-all">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-black font-bold mb-4">
                <PieChart className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-white">Dynamic Budget Guardrails</h3>
              <p className="mt-2 text-xs text-neutral-400 leading-relaxed">
                Establish monthly caps per category. Automated 80% threshold warnings and high-priority red alert
                banners keep your burn rate in check before you overspend.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-6 backdrop-blur-xl hover:border-neutral-700 transition-all">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-black font-bold mb-4">
                <BarChart3 className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-white">High-Definition Visual Analytics</h3>
              <p className="mt-2 text-xs text-neutral-400 leading-relaxed">
                Smooth Recharts graphs render monthly trend lines, donut category distributions, weekly cadence
                bars, and multi-year comparison reports.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-6 backdrop-blur-xl hover:border-neutral-700 transition-all">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-black font-bold mb-4">
                <Sparkles className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-white">Gemini 3.8 Flash AI Auditor</h3>
              <p className="mt-2 text-xs text-neutral-400 leading-relaxed">
                Detect abnormal spending spikes, recurring subscription leakage, and concrete savings
                opportunities with quantified estimates in your local currency.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-6 backdrop-blur-xl hover:border-neutral-700 transition-all">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-black font-bold mb-4">
                <Sliders className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-white">Instant Search & Multi-Filters</h3>
              <p className="mt-2 text-xs text-neutral-400 leading-relaxed">
                Filter across dates, 10 distinct categories, 6 payment methods (UPI, Cards, Cash), and numerical
                amount ranges with sub-millisecond response times.
              </p>
            </div>

            {/* Feature 5 */}
            <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-6 backdrop-blur-xl hover:border-neutral-700 transition-all">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-black font-bold mb-4">
                <ShieldCheck className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-white">Firebase Zero-Trust Security</h3>
              <p className="mt-2 text-xs text-neutral-400 leading-relaxed">
                Hardened Firestore security rules with strict identity checks and attribute validation guarantee
                that your income and expenses stay 100% private.
              </p>
            </div>

            {/* Feature 6 */}
            <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-6 backdrop-blur-xl hover:border-neutral-700 transition-all">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-black font-bold mb-4">
                <Globe className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-white">Multi-Format Statements</h3>
              <p className="mt-2 text-xs text-neutral-400 leading-relaxed">
                One-click export to printable PDF statements, multi-tab Excel files (.xls), standard CSV sheets, or
                complete raw JSON database backups.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 border-b border-neutral-900">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-500">
              User Endorsements
            </span>
            <h2 className="mt-2 text-3xl font-extrabold tracking-tight text-white font-['Space_Grotesk']">
              Trusted by Engineers and Founders
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((t, idx) => (
              <div
                key={idx}
                className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-6 backdrop-blur-xl flex flex-col justify-between"
              >
                <p className="text-xs text-neutral-300 leading-relaxed italic">
                  "{t.quote}"
                </p>
                <div className="mt-6 pt-4 border-t border-neutral-900 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-white">{t.author}</div>
                    <div className="text-[11px] text-neutral-500">{t.role}</div>
                  </div>
                  <span className="rounded-md border border-neutral-800 bg-neutral-900 px-2 py-0.5 text-[10px] font-mono text-emerald-400">
                    {t.metric}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 border-b border-neutral-900">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-500">
              Questions & Answers
            </span>
            <h2 className="mt-2 text-3xl font-extrabold tracking-tight text-white font-['Space_Grotesk']">
              Frequently Asked Questions
            </h2>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, index) => {
              const isOpen = openFaq === index;
              return (
                <div
                  key={index}
                  className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 overflow-hidden"
                >
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : index)}
                    className="flex w-full items-center justify-between p-5 text-left text-xs sm:text-sm font-bold text-white hover:bg-neutral-900/40 transition-colors"
                  >
                    <span>{faq.q}</span>
                    {isOpen ? (
                      <ChevronUp className="h-4 w-4 text-neutral-400 shrink-0" />
                    ) : (
                      <ChevronDown className="h-4 w-4 text-neutral-400 shrink-0" />
                    )}
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-xs text-neutral-400 leading-relaxed border-t border-neutral-900">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-black border-t border-neutral-900">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-white text-black font-extrabold text-xs">
              K
            </div>
            <span className="text-xs font-bold text-white font-['Space_Grotesk']">
              KURO EXPENSE
            </span>
            <span className="text-[11px] text-neutral-500">
              • Personal Expenses Tracking and Analysis System
            </span>
          </div>

          <div className="text-xs text-neutral-500">
            Crafted in Pure Monochrome • Bank-Grade Security
          </div>
        </div>
      </footer>
    </div>
  );
};
