import React, { useState, useEffect } from 'react';
import { X, TrendingUp, Calendar, Tag } from 'lucide-react';
import { Income, IncomeSource, INCOME_SOURCES } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface IncomeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Omit<Income, 'id' | 'userId' | 'createdAt'>) => Promise<void>;
  incomeToEdit?: Income | null;
}

export const IncomeModal: React.FC<IncomeModalProps> = ({
  isOpen,
  onClose,
  onSave,
  incomeToEdit,
}) => {
  const { currency } = useAuth();

  const [amount, setAmount] = useState<string>('');
  const [source, setSource] = useState<string>('Salary');
  const [date, setDate] = useState<string>(() => new Date().toISOString().slice(0, 10));
  const [notes, setNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    if (incomeToEdit) {
      setAmount(incomeToEdit.amount.toString());
      setSource(incomeToEdit.source);
      setDate(incomeToEdit.date);
      setNotes(incomeToEdit.notes || '');
    } else {
      setAmount('');
      setSource('Salary');
      setDate(new Date().toISOString().slice(0, 10));
      setNotes('');
    }
    setError('');
  }, [incomeToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setError('Please enter a valid amount greater than zero.');
      return;
    }
    if (!source.trim()) {
      setError('Please specify the income source.');
      return;
    }

    try {
      setIsSubmitting(true);
      setError('');
      await onSave({
        amount: numAmount,
        source: source.trim(),
        date,
        notes: notes.trim(),
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save income');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in">
      <div className="relative w-full max-w-lg rounded-2xl border border-neutral-800 bg-neutral-950 p-6 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-900">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-500 text-black font-bold">
              <TrendingUp className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {incomeToEdit ? 'Edit Income' : 'Add New Income'}
              </h2>
              <p className="text-xs text-neutral-400">Record positive cash credit</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-neutral-400 hover:bg-neutral-900 hover:text-white transition-colors"
            aria-label="Close modal"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {error && (
          <div className="mt-4 rounded-xl border border-rose-900/50 bg-rose-950/30 p-3 text-xs text-rose-300">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {/* Amount input */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
              Income Amount ({currency}) *
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-mono text-base font-bold text-emerald-400">
                {currency}
              </span>
              <input
                type="number"
                step="any"
                required
                placeholder="0.00"
                value={amount}
                onChange={e => setAmount(e.target.value)}
                className="w-full rounded-xl border border-neutral-800 bg-neutral-900/80 py-2.5 pl-9 pr-4 font-mono text-base font-bold text-white placeholder-neutral-600 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-all"
              />
            </div>
          </div>

          {/* Source selection */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
              Source *
            </label>
            <select
              value={source}
              onChange={e => setSource(e.target.value)}
              className="w-full rounded-xl border border-neutral-800 bg-neutral-900/80 px-3 py-2.5 text-xs text-white focus:border-white focus:outline-none focus:ring-1 focus:ring-white transition-all"
            >
              {INCOME_SOURCES.map(src => (
                <option key={src} value={src} className="bg-neutral-950 text-white">
                  {src}
                </option>
              ))}
            </select>
          </div>

          {/* Date & Notes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                Date *
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full rounded-xl border border-neutral-800 bg-neutral-900/80 px-3.5 py-2.5 text-xs text-white focus:border-white focus:outline-none focus:ring-1 focus:ring-white transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                Notes (Optional)
              </label>
              <input
                type="text"
                placeholder="Client name, bonus details, etc."
                value={notes}
                onChange={e => setNotes(e.target.value)}
                className="w-full rounded-xl border border-neutral-800 bg-neutral-900/80 px-3.5 py-2.5 text-xs text-white placeholder-neutral-600 focus:border-white focus:outline-none focus:ring-1 focus:ring-white transition-all"
              />
            </div>
          </div>

          {/* Submit button */}
          <div className="mt-6 flex items-center justify-end gap-3 pt-3 border-t border-neutral-900">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-neutral-800 px-4 py-2.5 text-xs font-medium text-neutral-400 hover:bg-neutral-900 hover:text-white transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="rounded-xl bg-white px-5 py-2.5 text-xs font-bold text-black hover:bg-neutral-200 active:scale-95 disabled:opacity-50 transition-all shadow-md"
            >
              {isSubmitting ? 'Saving...' : incomeToEdit ? 'Update Income' : 'Save Income'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
