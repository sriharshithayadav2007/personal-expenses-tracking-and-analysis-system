import React, { useMemo } from 'react';
import {
  PieChart,
  Plus,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  Sliders,
  Trash2,
  Edit2,
  ShieldCheck,
  Flame,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useExpense } from '../../context/ExpenseContext';
import { ExpenseCategory, EXPENSE_CATEGORIES } from '../../types';
import { calculateBudgetStatus } from '../../utils/calculations';

interface BudgetViewProps {
  onOpenSetBudget: (cat?: ExpenseCategory) => void;
}

export const BudgetView: React.FC<BudgetViewProps> = ({ onOpenSetBudget }) => {
  const { currency } = useAuth();
  const { budgets, expenses, deleteBudget } = useExpense();

  // Current month expenses
  const now = new Date();
  const currentMonth = now.getMonth() + 1;
  const currentYear = now.getFullYear();

  const currentMonthExpenses = useMemo(() => {
    return expenses.filter(e => {
      const d = new Date(e.date);
      return d.getMonth() + 1 === currentMonth && d.getFullYear() === currentYear;
    });
  }, [expenses, currentMonth, currentYear]);

  // Spending per category for current month
  const categorySpend = useMemo(() => {
    const map: Record<string, number> = {};
    currentMonthExpenses.forEach(e => {
      map[e.category] = (map[e.category] || 0) + e.amount;
    });
    return map;
  }, [currentMonthExpenses]);

  // Overall budget status
  const totalBudgetLimit = budgets.reduce((sum, b) => sum + b.limit, 0);
  const totalBudgetSpent = budgets.reduce((sum, b) => sum + (categorySpend[b.category] || 0), 0);
  const overallPercentage = totalBudgetLimit > 0 ? Math.round((totalBudgetSpent / totalBudgetLimit) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white font-['Space_Grotesk']">
            Category Budget System
          </h1>
          <p className="text-xs text-neutral-400">
            Set proactive spending caps with automatic 80% warnings and overspend guardrails
          </p>
        </div>

        <button
          onClick={() => onOpenSetBudget()}
          className="flex items-center justify-center gap-1.5 rounded-xl bg-white px-4 py-2.5 text-xs font-bold text-black hover:bg-neutral-200 active:scale-95 transition-all shadow-md self-start sm:self-auto"
        >
          <Plus className="h-4 w-4 stroke-[2.5]" />
          <span>Set Category Budget</span>
        </button>
      </div>

      {/* Aggregate Budget Bar Card */}
      <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-6 backdrop-blur-xl">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
              Monthly Budget Utilization ({now.toLocaleString('default', { month: 'long', year: 'numeric' })})
            </span>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-extrabold text-white font-['Space_Grotesk']">
                {currency}
                {totalBudgetSpent.toLocaleString()}
              </span>
              <span className="text-xs text-neutral-400 font-mono">
                / {currency}
                {totalBudgetLimit.toLocaleString()} allocated
              </span>
            </div>
          </div>

          <div className="text-right">
            <span
              className={`font-mono text-xl sm:text-2xl font-extrabold ${
                overallPercentage >= 100
                  ? 'text-rose-400'
                  : overallPercentage >= 80
                  ? 'text-amber-400'
                  : 'text-white'
              }`}
            >
              {overallPercentage}%
            </span>
            <span className="block text-[10px] text-neutral-500 uppercase tracking-wider">
              {totalBudgetLimit >= totalBudgetSpent
                ? `${currency}${(totalBudgetLimit - totalBudgetSpent).toLocaleString()} remaining`
                : `${currency}${(totalBudgetSpent - totalBudgetLimit).toLocaleString()} exceeded`}
            </span>
          </div>
        </div>

        {/* Progress bar */}
        <div className="mt-4 h-2.5 w-full rounded-full bg-neutral-900 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              overallPercentage >= 100
                ? 'bg-rose-500'
                : overallPercentage >= 80
                ? 'bg-amber-400'
                : 'bg-white'
            }`}
            style={{ width: `${Math.min(100, overallPercentage)}%` }}
          />
        </div>
      </div>

      {/* Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {budgets.map(b => {
          const spent = categorySpend[b.category] || 0;
          const status = calculateBudgetStatus(b.limit, spent);

          return (
            <div
              key={b.id}
              className={`relative overflow-hidden rounded-2xl border p-5 backdrop-blur-xl transition-all ${
                status.status === 'exceeded'
                  ? 'border-rose-900/60 bg-rose-950/20 shadow-lg shadow-rose-950/10'
                  : status.status === 'warning'
                  ? 'border-amber-900/60 bg-amber-950/20 shadow-lg shadow-amber-950/10'
                  : 'border-neutral-800/80 bg-neutral-950/70'
              }`}
            >
              {/* Header */}
              <div className="flex items-center justify-between pb-3 border-b border-neutral-900/80">
                <div className="flex items-center gap-2">
                  <div
                    className={`flex h-8 w-8 items-center justify-center rounded-xl font-bold text-xs ${
                      status.status === 'exceeded'
                        ? 'bg-rose-500 text-black'
                        : status.status === 'warning'
                        ? 'bg-amber-400 text-black'
                        : 'bg-neutral-900 text-white'
                    }`}
                  >
                    {b.category.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-white">{b.category}</h3>
                    <span className="text-[10px] text-neutral-400 uppercase tracking-wider font-mono">
                      Limit: {currency}
                      {b.limit.toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onOpenSetBudget(b.category)}
                    className="p-1 rounded text-neutral-400 hover:text-white transition-colors"
                    aria-label={`Edit ${b.category} budget`}
                  >
                    <Edit2 className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => deleteBudget(b.id)}
                    className="p-1 rounded text-neutral-400 hover:text-rose-400 transition-colors"
                    aria-label={`Delete ${b.category} budget`}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>

              {/* Status Badge */}
              <div className="mt-4 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-neutral-400">Spent this month</span>
                  <div className="text-xl font-extrabold text-white font-mono">
                    {currency}
                    {spent.toLocaleString()}
                  </div>
                </div>

                <div>
                  {status.status === 'exceeded' ? (
                    <span className="inline-flex items-center gap-1 rounded-full border border-rose-800 bg-rose-950 px-2.5 py-1 text-[10px] font-bold text-rose-300 uppercase tracking-wide">
                      <Flame className="h-3 w-3" />
                      <span>Exceeded ({status.percentage}%)</span>
                    </span>
                  ) : status.status === 'warning' ? (
                    <span className="inline-flex items-center gap-1 rounded-full border border-amber-800 bg-amber-950 px-2.5 py-1 text-[10px] font-bold text-amber-300 uppercase tracking-wide">
                      <AlertTriangle className="h-3 w-3" />
                      <span>Warning ({status.percentage}%)</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 rounded-full border border-neutral-800 bg-neutral-900 px-2.5 py-1 text-[10px] font-semibold text-neutral-300">
                      <CheckCircle className="h-3 w-3 text-emerald-400" />
                      <span>{status.percentage}% Used</span>
                    </span>
                  )}
                </div>
              </div>

              {/* Progress bar */}
              <div className="mt-3 h-2 w-full rounded-full bg-neutral-900 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    status.status === 'exceeded'
                      ? 'bg-rose-500'
                      : status.status === 'warning'
                      ? 'bg-amber-400'
                      : 'bg-white'
                  }`}
                  style={{ width: `${Math.min(100, status.percentage)}%` }}
                />
              </div>

              {/* Remaining calculation */}
              <div className="mt-3 flex items-center justify-between text-xs text-neutral-400 pt-2 border-t border-neutral-900/60 font-mono">
                <span>Remaining:</span>
                <span
                  className={
                    status.status === 'exceeded'
                      ? 'text-rose-400 font-bold'
                      : 'text-neutral-200 font-bold'
                  }
                >
                  {status.status === 'exceeded'
                    ? `-${currency}${(spent - b.limit).toLocaleString()} over`
                    : `${currency}${status.remaining.toLocaleString()}`}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
