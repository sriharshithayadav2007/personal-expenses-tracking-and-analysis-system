import React from 'react';
import {
  LayoutDashboard,
  Receipt,
  TrendingUp,
  PieChart,
  BarChart3,
  FileText,
  Settings,
  Plus,
} from 'lucide-react';
import { NavigationTab } from '../types';

interface MobileNavProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  onOpenAddExpense: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  activeTab,
  setActiveTab,
  onOpenAddExpense,
}) => {
  const navTabs: { tab: NavigationTab; label: string; icon: React.ElementType }[] = [
    { tab: 'dashboard', label: 'Dash', icon: LayoutDashboard },
    { tab: 'expenses', label: 'Expenses', icon: Receipt },
    { tab: 'income', label: 'Income', icon: TrendingUp },
    { tab: 'budget', label: 'Budget', icon: PieChart },
    { tab: 'analytics', label: 'Analytics', icon: BarChart3 },
    { tab: 'reports', label: 'Reports', icon: FileText },
    { tab: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <>
      {/* Floating Add Action Button on Mobile */}
      <div className="fixed bottom-20 right-5 z-40 lg:hidden">
        <button
          onClick={onOpenAddExpense}
          className="flex h-13 w-13 items-center justify-center rounded-2xl bg-white text-black shadow-2xl active:scale-95 transition-all focus:outline-none ring-4 ring-neutral-900"
          aria-label="Quick Add Expense"
        >
          <Plus className="h-6 w-6 stroke-[2.5]" />
        </button>
      </div>

      {/* Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 flex h-16 items-center justify-around border-t border-neutral-900 bg-black/95 backdrop-blur-lg px-2 lg:hidden">
        {navTabs.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.tab;
          return (
            <button
              key={item.tab}
              onClick={() => setActiveTab(item.tab)}
              className={`flex flex-col items-center justify-center py-1 px-2 transition-all ${
                isActive ? 'text-white font-bold' : 'text-neutral-500 hover:text-neutral-300'
              }`}
              aria-label={item.label}
            >
              <div
                className={`flex h-7 w-7 items-center justify-center rounded-lg transition-colors ${
                  isActive ? 'bg-white text-black' : 'text-current'
                }`}
              >
                <Icon className="h-4 w-4" />
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight font-medium">
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>
    </>
  );
};
