export type ExpenseCategory =
  | 'Food'
  | 'Transport'
  | 'Shopping'
  | 'Bills'
  | 'Entertainment'
  | 'Education'
  | 'Health'
  | 'Travel'
  | 'Rent'
  | 'Other';

export const EXPENSE_CATEGORIES: ExpenseCategory[] = [
  'Food',
  'Transport',
  'Shopping',
  'Bills',
  'Entertainment',
  'Education',
  'Health',
  'Travel',
  'Rent',
  'Other',
];

export type PaymentMethod =
  | 'Cash'
  | 'Credit Card'
  | 'Debit Card'
  | 'UPI'
  | 'Net Banking'
  | 'Other';

export const PAYMENT_METHODS: PaymentMethod[] = [
  'UPI',
  'Credit Card',
  'Debit Card',
  'Cash',
  'Net Banking',
  'Other',
];

export type IncomeSource =
  | 'Salary'
  | 'Freelance'
  | 'Investment'
  | 'Business'
  | 'Bonus'
  | 'Gift'
  | 'Other';

export const INCOME_SOURCES: IncomeSource[] = [
  'Salary',
  'Freelance',
  'Investment',
  'Business',
  'Bonus',
  'Gift',
  'Other',
];

export interface Expense {
  id: string;
  userId: string;
  amount: number;
  category: ExpenseCategory;
  description: string;
  paymentMethod: PaymentMethod;
  date: string; // YYYY-MM-DD
  notes?: string;
  createdAt: string;
}

export interface Income {
  id: string;
  userId: string;
  amount: number;
  source: IncomeSource | string;
  date: string; // YYYY-MM-DD
  notes?: string;
  createdAt: string;
}

export interface Budget {
  id: string;
  userId: string;
  category: ExpenseCategory;
  limit: number;
  month: number; // 1 - 12
  year: number;
  createdAt: string;
}

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  photoURL?: string;
  currency: string; // e.g. "₹", "$", "€", "£"
  createdAt: string;
  isGuest?: boolean;
}

export interface AiInsightsResponse {
  summary: string;
  unusualSpending: string[];
  savingsOpportunities: string[];
  predictedEndOfMonthSpend: number;
  recurringExpenseAlerts: string[];
  keyTakeaway: string;
}

export type CurrencyCode = 'INR' | 'USD' | 'EUR' | 'GBP' | 'JPY' | 'CAD' | 'AUD';

export interface CurrencyConfig {
  code: CurrencyCode;
  symbol: string;
  name: string;
}

export const SUPPORTED_CURRENCIES: CurrencyConfig[] = [
  { code: 'INR', symbol: '₹', name: 'Indian Rupee (₹)' },
  { code: 'USD', symbol: '$', name: 'US Dollar ($)' },
  { code: 'EUR', symbol: '€', name: 'Euro (€)' },
  { code: 'GBP', symbol: '£', name: 'British Pound (£)' },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen (¥)' },
  { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar (C$)' },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar (A$)' },
];

export type NavigationTab =
  | 'dashboard'
  | 'expenses'
  | 'income'
  | 'budget'
  | 'analytics'
  | 'reports'
  | 'settings';
