import React, { useState } from 'react';
import {
  Receipt,
  Search,
  Filter,
  Plus,
  Trash2,
  Edit2,
  X,
  ArrowUpDown,
  Tag,
  CreditCard,
  Calendar,
  SlidersHorizontal,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useExpense } from '../../context/ExpenseContext';
import {
  Expense,
  ExpenseCategory,
  PaymentMethod,
  EXPENSE_CATEGORIES,
  PAYMENT_METHODS,
} from '../../types';

interface ExpensesViewProps {
  onOpenAddExpense: () => void;
  onEditExpense: (exp: Expense) => void;
}

export const ExpensesView: React.FC<ExpensesViewProps> = ({
  onOpenAddExpense,
  onEditExpense,
}) => {
  const { currency } = useAuth();
  const {
    filteredExpenses,
    filterState,
    setFilterState,
    resetFilters,
    deleteExpense,
  } = useExpense();

  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  const totalFilteredAmount = filteredExpenses.reduce((sum, item) => sum + item.amount, 0);

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white font-['Space_Grotesk']">
            Expenses Management
          </h1>
          <p className="text-xs text-neutral-400">
            Track, filter, and audit all recorded debits ({filteredExpenses.length} entries)
          </p>
        </div>

        <button
          onClick={onOpenAddExpense}
          className="flex items-center justify-center gap-1.5 rounded-xl bg-white px-4 py-2.5 text-xs font-bold text-black hover:bg-neutral-200 active:scale-95 transition-all shadow-md self-start sm:self-auto"
        >
          <Plus className="h-4 w-4 stroke-[2.5]" />
          <span>Add Expense</span>
        </button>
      </div>

      {/* Filter and Instant Search Toolbar */}
      <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-4 backdrop-blur-xl space-y-3.5">
        <div className="flex flex-col md:flex-row items-center gap-3">
          {/* Instant Search Bar */}
          <div className="relative flex-1 w-full">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
            <input
              type="text"
              placeholder="Instant search by description, category, notes, or method..."
              value={filterState.searchQuery}
              onChange={e => setFilterState(prev => ({ ...prev, searchQuery: e.target.value }))}
              className="w-full rounded-xl border border-neutral-800 bg-neutral-900/90 py-2.5 pl-10 pr-4 text-xs text-white placeholder-neutral-500 focus:border-white focus:outline-none focus:ring-1 focus:ring-white transition-all"
            />
            {filterState.searchQuery && (
              <button
                onClick={() => setFilterState(prev => ({ ...prev, searchQuery: '' }))}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-white"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          {/* Date Presets */}
          <div className="flex items-center gap-1.5 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
            {(['all', 'this-month', 'last-month', 'this-week'] as const).map(range => (
              <button
                key={range}
                onClick={() => setFilterState(prev => ({ ...prev, dateRange: range }))}
                className={`rounded-lg px-3 py-2 text-xs font-medium whitespace-nowrap transition-colors ${
                  filterState.dateRange === range
                    ? 'bg-white text-black font-bold'
                    : 'bg-neutral-900 text-neutral-400 hover:text-white'
                }`}
              >
                {range === 'all'
                  ? 'All Time'
                  : range === 'this-month'
                  ? 'This Month'
                  : range === 'last-month'
                  ? 'Last Month'
                  : 'This Week'}
              </button>
            ))}

            <button
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
              className={`flex items-center gap-1.5 rounded-lg border border-neutral-800 px-3 py-2 text-xs font-medium transition-colors ${
                showAdvancedFilters ? 'bg-neutral-800 text-white' : 'bg-neutral-900 text-neutral-400 hover:text-white'
              }`}
            >
              <SlidersHorizontal className="h-3.5 w-3.5" />
              <span>Filters</span>
            </button>
          </div>
        </div>

        {/* Advanced Filters Expandable Drawer */}
        {showAdvancedFilters && (
          <div className="pt-3 border-t border-neutral-900 grid grid-cols-1 sm:grid-cols-3 gap-3 animate-in fade-in">
            {/* Category Dropdown */}
            <div>
              <label className="block text-[11px] font-semibold text-neutral-400 uppercase tracking-wider mb-1">
                Category
              </label>
              <select
                value={filterState.category}
                onChange={e => setFilterState(prev => ({ ...prev, category: e.target.value }))}
                className="w-full rounded-xl border border-neutral-800 bg-neutral-900 px-3 py-2 text-xs text-white focus:outline-none focus:border-white"
              >
                <option value="All">All Categories</option>
                {EXPENSE_CATEGORIES.map(c => (
                  <option key={c} value={c} className="bg-neutral-950">
                    {c}
                  </option>
                ))}
              </select>
            </div>

            {/* Payment Method Dropdown */}
            <div>
              <label className="block text-[11px] font-semibold text-neutral-400 uppercase tracking-wider mb-1">
                Payment Method
              </label>
              <select
                value={filterState.paymentMethod}
                onChange={e => setFilterState(prev => ({ ...prev, paymentMethod: e.target.value }))}
                className="w-full rounded-xl border border-neutral-800 bg-neutral-900 px-3 py-2 text-xs text-white focus:outline-none focus:border-white"
              >
                <option value="All">All Methods</option>
                {PAYMENT_METHODS.map(m => (
                  <option key={m} value={m} className="bg-neutral-950">
                    {m}
                  </option>
                ))}
              </select>
            </div>

            {/* Max Amount Filter */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
                  Max Amount: {currency}
                  {filterState.maxAmount.toLocaleString()}
                </label>
                <button
                  onClick={resetFilters}
                  className="text-[10px] text-neutral-500 hover:text-white underline"
                >
                  Reset all
                </button>
              </div>
              <input
                type="range"
                min="0"
                max="100000"
                step="500"
                value={filterState.maxAmount}
                onChange={e => setFilterState(prev => ({ ...prev, maxAmount: Number(e.target.value) }))}
                className="w-full accent-white cursor-pointer"
              />
            </div>
          </div>
        )}

        {/* Filter summary bar */}
        <div className="flex items-center justify-between pt-2 text-[11px] text-neutral-500">
          <div>
            Showing <span className="font-semibold text-white">{filteredExpenses.length}</span> matching
            transaction{filteredExpenses.length === 1 ? '' : 's'}
          </div>
          <div className="font-mono">
            Filtered Total:{' '}
            <span className="font-bold text-white">
              {currency}
              {totalFilteredAmount.toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      {/* Expenses Table / Cards */}
      <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 backdrop-blur-xl overflow-hidden">
        {filteredExpenses.length === 0 ? (
          <div className="p-12 text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-neutral-900 text-neutral-500 mb-3">
              <Receipt className="h-6 w-6" />
            </div>
            <h3 className="text-sm font-bold text-white">No transactions found</h3>
            <p className="mt-1 text-xs text-neutral-500">
              Try adjusting your search query or reset your filters.
            </p>
            <button
              onClick={resetFilters}
              className="mt-4 rounded-xl border border-neutral-800 bg-neutral-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-neutral-800"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-neutral-900 bg-neutral-900/50 text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
                <tr>
                  <th className="py-3.5 pl-6 pr-4">Description</th>
                  <th className="py-3.5 px-4">Category</th>
                  <th className="py-3.5 px-4">Date</th>
                  <th className="py-3.5 px-4">Method</th>
                  <th className="py-3.5 px-4 text-right">Amount</th>
                  <th className="py-3.5 pr-6 pl-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-900">
                {filteredExpenses.map(item => (
                  <tr
                    key={item.id}
                    className="group hover:bg-neutral-900/40 transition-colors"
                  >
                    <td className="py-3 pl-6 pr-4">
                      <div className="font-semibold text-white">{item.description}</div>
                      {item.notes && (
                        <div className="text-[11px] text-neutral-500 truncate max-w-xs">
                          {item.notes}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center rounded-md border border-neutral-800 bg-neutral-900 px-2 py-0.5 text-[11px] font-medium text-neutral-300">
                        {item.category}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-neutral-400 whitespace-nowrap">
                      {item.date}
                    </td>
                    <td className="py-3 px-4 text-neutral-400 whitespace-nowrap">
                      {item.paymentMethod}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-white whitespace-nowrap">
                      -{currency}
                      {item.amount.toLocaleString()}
                    </td>
                    <td className="py-3 pr-6 pl-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => onEditExpense(item)}
                          className="rounded-lg p-1.5 text-neutral-400 hover:bg-neutral-800 hover:text-white transition-colors"
                          aria-label="Edit transaction"
                        >
                          <Edit2 className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => deleteExpense(item.id)}
                          className="rounded-lg p-1.5 text-neutral-400 hover:bg-neutral-800 hover:text-rose-400 transition-colors"
                          aria-label="Delete transaction"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
