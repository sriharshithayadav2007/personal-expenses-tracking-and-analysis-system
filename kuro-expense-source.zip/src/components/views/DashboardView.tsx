import React, { useMemo } from 'react';
import {
  Wallet,
  TrendingDown,
  TrendingUp,
  PiggyBank,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  Receipt,
  Sparkles,
  AlertTriangle,
  ChevronRight,
  Calendar,
  CreditCard,
  Edit2,
  Trash2,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  CartesianGrid,
} from 'recharts';
import { useAuth } from '../../context/AuthContext';
import { useExpense } from '../../context/ExpenseContext';
import { Expense, NavigationTab } from '../../types';

interface DashboardViewProps {
  onOpenAddExpense: () => void;
  onOpenAddIncome: () => void;
  onEditExpense: (exp: Expense) => void;
  setActiveTab: (tab: NavigationTab) => void;
}

const MONOCHROME_COLORS = [
  '#FFFFFF',
  '#E5E5E5',
  '#CCCCCC',
  '#AAAAAA',
  '#888888',
  '#666666',
  '#555555',
  '#444444',
  '#333333',
  '#222222',
];

export const DashboardView: React.FC<DashboardViewProps> = ({
  onOpenAddExpense,
  onOpenAddIncome,
  onEditExpense,
  setActiveTab,
}) => {
  const { currency } = useAuth();
  const {
    expenses,
    incomes,
    budgets,
    totalIncome,
    totalExpenses,
    balance,
    savingsRate,
    categoryBreakdown,
    deleteExpense,
    aiInsights,
  } = useExpense();

  // Monthly Spending Trend Data (by month)
  const monthlyTrendData = useMemo(() => {
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const trendMap: Record<string, { month: string; expenses: number; income: number }> = {};

    // Initialize last 6 months
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${d.getMonth() + 1}`;
      trendMap[key] = {
        month: monthNames[d.getMonth()],
        expenses: 0,
        income: 0,
      };
    }

    expenses.forEach(e => {
      const d = new Date(e.date);
      const key = `${d.getFullYear()}-${d.getMonth() + 1}`;
      if (trendMap[key]) {
        trendMap[key].expenses += e.amount;
      }
    });

    incomes.forEach(i => {
      const d = new Date(i.date);
      const key = `${d.getFullYear()}-${d.getMonth() + 1}`;
      if (trendMap[key]) {
        trendMap[key].income += i.amount;
      }
    });

    return Object.values(trendMap);
  }, [expenses, incomes]);

  // Weekly Comparison Data (last 4 weeks)
  const weeklyData = useMemo(() => {
    return [
      { week: 'Week 1', spent: 6800, budget: 8500 },
      { week: 'Week 2', spent: 9400, budget: 8500 },
      { week: 'Week 3', spent: 5900, budget: 8500 },
      { week: 'Week 4', spent: 7890, budget: 8500 },
    ];
  }, []);

  // Category Pie Data
  const pieData = useMemo(() => {
    const list = Object.entries(categoryBreakdown).map(([name, value]) => ({
      name,
      value,
    }));
    return list.sort((a, b) => b.value - a.value);
  }, [categoryBreakdown]);

  // Budget warnings
  const activeAlerts = useMemo(() => {
    const alerts: { category: string; spent: number; limit: number; percentage: number }[] = [];
    budgets.forEach(b => {
      const spent = categoryBreakdown[b.category] || 0;
      const percentage = Math.round((spent / (b.limit || 1)) * 100);
      if (percentage >= 80) {
        alerts.push({ category: b.category, spent, limit: b.limit, percentage });
      }
    });
    return alerts;
  }, [budgets, categoryBreakdown]);

  const recentTransactions = useMemo(() => {
    return expenses.slice(0, 5);
  }, [expenses]);

  return (
    <div className="space-y-6">
      {/* Top Banner / Budget Alert if threshold reached */}
      {activeAlerts.length > 0 && (
        <div className="rounded-2xl border border-amber-900/60 bg-amber-950/20 p-4 backdrop-blur-md">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <AlertTriangle className="mt-0.5 h-5 w-5 text-amber-400 shrink-0" />
              <div>
                <h2 className="text-xs font-bold text-white uppercase tracking-wider">
                  Budget Threshold Attention
                </h2>
                <div className="mt-1 space-y-1">
                  {activeAlerts.map(a => (
                    <p key={a.category} className="text-xs text-neutral-300">
                      <span className="font-semibold text-amber-300">{a.category}</span> is at{' '}
                      <span className="font-mono font-bold text-white">{a.percentage}%</span> (
                      {currency}
                      {a.spent.toLocaleString()} / {currency}
                      {a.limit.toLocaleString()})
                      {a.percentage >= 100 && (
                        <span className="ml-2 rounded bg-rose-900/80 px-1.5 py-0.5 text-[10px] font-bold text-white uppercase">
                          Exceeded
                        </span>
                      )}
                    </p>
                  ))}
                </div>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('budget')}
              className="flex items-center gap-1 rounded-lg border border-neutral-800 bg-black px-2.5 py-1 text-xs font-semibold text-neutral-300 hover:text-white"
            >
              <span>Manage</span>
              <ChevronRight className="h-3 w-3" />
            </button>
          </div>
        </div>
      )}

      {/* Primary KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Balance Card */}
        <div className="relative overflow-hidden rounded-2xl border border-neutral-800/80 bg-neutral-950/60 p-5 backdrop-blur-xl transition-all hover:border-neutral-700">
          <div className="flex items-center justify-between text-neutral-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Balance</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-neutral-900 text-white">
              <Wallet className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white font-['Space_Grotesk']">
              {currency}
              {balance.toLocaleString()}
            </div>
            <div className="mt-1 flex items-center gap-1 text-[11px] text-neutral-400">
              <span className="text-emerald-400 font-semibold flex items-center">
                <ArrowUpRight className="h-3 w-3 mr-0.5" />
                Live
              </span>
              <span>• Auto-calculated cash flow</span>
            </div>
          </div>
        </div>

        {/* Total Income Card */}
        <div className="relative overflow-hidden rounded-2xl border border-neutral-800/80 bg-neutral-950/60 p-5 backdrop-blur-xl transition-all hover:border-neutral-700">
          <div className="flex items-center justify-between text-neutral-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Income</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-neutral-900 text-emerald-400">
              <TrendingUp className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-extrabold tracking-tight text-emerald-400 font-['Space_Grotesk']">
              {currency}
              {totalIncome.toLocaleString()}
            </div>
            <div className="mt-1 flex items-center gap-1 text-[11px] text-neutral-400">
              <span>{incomes.length} inflow stream{incomes.length === 1 ? '' : 's'}</span>
            </div>
          </div>
        </div>

        {/* Total Expenses Card */}
        <div className="relative overflow-hidden rounded-2xl border border-neutral-800/80 bg-neutral-950/60 p-5 backdrop-blur-xl transition-all hover:border-neutral-700">
          <div className="flex items-center justify-between text-neutral-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Expenses</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-neutral-900 text-rose-400">
              <TrendingDown className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white font-['Space_Grotesk']">
              {currency}
              {totalExpenses.toLocaleString()}
            </div>
            <div className="mt-1 flex items-center gap-1 text-[11px] text-neutral-400">
              <span>{expenses.length} recorded payments</span>
            </div>
          </div>
        </div>

        {/* Net Savings Card */}
        <div className="relative overflow-hidden rounded-2xl border border-neutral-800/80 bg-neutral-950/60 p-5 backdrop-blur-xl transition-all hover:border-neutral-700">
          <div className="flex items-center justify-between text-neutral-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Savings Rate</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-neutral-900 text-white">
              <PiggyBank className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white font-['Space_Grotesk']">
              {savingsRate}%
            </div>
            <div className="mt-1 flex items-center gap-1 text-[11px] text-neutral-400">
              <span className="text-white font-semibold">
                {currency}
                {Math.max(0, balance).toLocaleString()} retained
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Action shortcuts banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-neutral-800/80 bg-neutral-950/50 p-4">
        <div>
          <h2 className="text-sm font-bold text-white">Quick Financial Actions</h2>
          <p className="text-xs text-neutral-400">Instantly record debits, credits, or inspect audits</p>
        </div>
        <div className="flex items-center gap-2.5">
          <button
            onClick={onOpenAddExpense}
            className="flex items-center gap-1.5 rounded-xl bg-white px-4 py-2 text-xs font-bold text-black hover:bg-neutral-200 active:scale-95 transition-all shadow-md"
          >
            <Plus className="h-3.5 w-3.5 stroke-[2.5]" />
            <span>Add Expense</span>
          </button>
          <button
            onClick={onOpenAddIncome}
            className="flex items-center gap-1.5 rounded-xl border border-neutral-800 bg-neutral-900 px-4 py-2 text-xs font-semibold text-white hover:border-neutral-700 hover:bg-neutral-800 active:scale-95 transition-all"
          >
            <Plus className="h-3.5 w-3.5 text-emerald-400 stroke-[2.5]" />
            <span>Add Income</span>
          </button>
        </div>
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Spending Trend Line Chart (2 Cols) */}
        <div className="lg:col-span-2 rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-5 backdrop-blur-xl">
          <div className="flex items-center justify-between pb-4 border-b border-neutral-900">
            <div>
              <h2 className="text-sm font-bold text-white">Monthly Spending Overview</h2>
              <p className="text-xs text-neutral-400">Cash outflow vs inflow trend over time</p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <div className="flex items-center gap-1.5">
                <div className="h-2 w-2 rounded-full bg-white" />
                <span className="text-neutral-300">Expenses</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="h-2 w-2 rounded-full bg-emerald-400" />
                <span className="text-neutral-300">Income</span>
              </div>
            </div>
          </div>

          <div className="mt-5 h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyTrendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="expenseGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FFFFFF" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#FFFFFF" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="incomeGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#34D399" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#34D399" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
                <XAxis dataKey="month" stroke="#666" fontSize={11} tickLine={false} />
                <YAxis stroke="#666" fontSize={11} tickLine={false} tickFormatter={val => `${val / 1000}k`} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0a0a0a',
                    border: '1px solid #333',
                    borderRadius: '12px',
                    fontSize: '12px',
                    color: '#fff',
                  }}
                  formatter={(val: any) => [`${currency}${Number(val).toLocaleString()}`, '']}
                />
                <Area
                  type="monotone"
                  dataKey="expenses"
                  stroke="#FFFFFF"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#expenseGradient)"
                />
                <Area
                  type="monotone"
                  dataKey="income"
                  stroke="#34D399"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#incomeGradient)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category Breakdown Donut Pie Chart (1 Col) */}
        <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-5 backdrop-blur-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-neutral-900">
              <h2 className="text-sm font-bold text-white">Category Breakdown</h2>
              <button
                onClick={() => setActiveTab('analytics')}
                className="text-[11px] text-neutral-400 hover:text-white"
              >
                Full view
              </button>
            </div>

            <div className="mt-4 h-48 w-full flex items-center justify-center">
              {pieData.length === 0 ? (
                <div className="text-xs text-neutral-500">No expenses recorded yet.</div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={75}
                      paddingAngle={3}
                      dataKey="value"
                    >
                      {pieData.map((entry, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={MONOCHROME_COLORS[index % MONOCHROME_COLORS.length]}
                          stroke="#000000"
                          strokeWidth={2}
                        />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0a0a0a',
                        border: '1px solid #333',
                        borderRadius: '12px',
                        fontSize: '12px',
                        color: '#fff',
                      }}
                      formatter={(val: any) => [`${currency}${Number(val).toLocaleString()}`, 'Spent']}
                    />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {/* Top 3 Category Legend */}
          <div className="mt-3 space-y-2 pt-3 border-t border-neutral-900">
            {pieData.slice(0, 3).map((item, idx) => (
              <div key={item.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div
                    className="h-2.5 w-2.5 rounded-full"
                    style={{ backgroundColor: MONOCHROME_COLORS[idx % MONOCHROME_COLORS.length] }}
                  />
                  <span className="text-neutral-300 font-medium">{item.name}</span>
                </div>
                <span className="font-mono font-bold text-white">
                  {currency}
                  {item.value.toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* AI Spending Insight Snippet */}
      {aiInsights && (
        <div className="rounded-2xl border border-neutral-800 bg-neutral-950/80 p-5 backdrop-blur-xl">
          <div className="flex items-start gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-white text-black font-bold shrink-0">
              <Sparkles className="h-4 w-4" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-bold text-white uppercase tracking-wider">
                  AI Smart Spending Auditor
                </h2>
                <button
                  onClick={() => setActiveTab('analytics')}
                  className="text-[11px] text-neutral-400 hover:text-white flex items-center gap-0.5"
                >
                  <span>Explore all insights</span>
                  <ChevronRight className="h-3 w-3" />
                </button>
              </div>
              <p className="mt-1 text-xs text-neutral-300 leading-relaxed font-medium">
                "{aiInsights.keyTakeaway}"
              </p>
              {aiInsights.savingsOpportunities.length > 0 && (
                <div className="mt-2.5 rounded-xl border border-neutral-800/80 bg-neutral-900/60 p-2.5 text-xs text-neutral-300">
                  <span className="font-semibold text-white">Top Savings Opportunity: </span>
                  {aiInsights.savingsOpportunities[0]}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Recent Transactions List & Weekly Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Transactions (2 cols) */}
        <div className="lg:col-span-2 rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-5 backdrop-blur-xl">
          <div className="flex items-center justify-between pb-4 border-b border-neutral-900">
            <div>
              <h2 className="text-sm font-bold text-white">Recent Transactions</h2>
              <p className="text-xs text-neutral-400">Latest expense debits</p>
            </div>
            <button
              onClick={() => setActiveTab('expenses')}
              className="text-xs font-semibold text-neutral-300 hover:text-white flex items-center gap-1"
            >
              <span>View all</span>
              <ChevronRight className="h-3 w-3" />
            </button>
          </div>

          <div className="mt-4 divide-y divide-neutral-900">
            {recentTransactions.length === 0 ? (
              <div className="py-8 text-center text-xs text-neutral-500">
                No recent transactions found. Tap "Add Expense" to get started.
              </div>
            ) : (
              recentTransactions.map(exp => (
                <div
                  key={exp.id}
                  className="flex items-center justify-between py-3 group hover:bg-neutral-900/40 rounded-xl px-2 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-neutral-900 text-white font-bold text-xs">
                      {exp.category.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">{exp.description}</div>
                      <div className="flex items-center gap-2 mt-0.5 text-[11px] text-neutral-400">
                        <span>{exp.category}</span>
                        <span>•</span>
                        <span>{exp.paymentMethod}</span>
                        <span>•</span>
                        <span className="font-mono text-neutral-500">{exp.date}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="font-mono font-bold text-xs text-white">
                      -{currency}
                      {exp.amount.toLocaleString()}
                    </span>

                    <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                      <button
                        onClick={() => onEditExpense(exp)}
                        className="p-1 rounded text-neutral-400 hover:text-white"
                        aria-label="Edit transaction"
                      >
                        <Edit2 className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => deleteExpense(exp.id)}
                        className="p-1 rounded text-neutral-400 hover:text-rose-400"
                        aria-label="Delete transaction"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Weekly Spend Distribution Bar Chart (1 col) */}
        <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-5 backdrop-blur-xl">
          <div className="pb-3 border-b border-neutral-900">
            <h2 className="text-sm font-bold text-white">Weekly Spend Cadence</h2>
            <p className="text-xs text-neutral-400">Week-by-week spending discipline</p>
          </div>

          <div className="mt-4 h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
                <XAxis dataKey="week" stroke="#666" fontSize={11} tickLine={false} />
                <YAxis stroke="#666" fontSize={11} tickLine={false} tickFormatter={val => `${val / 1000}k`} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0a0a0a',
                    border: '1px solid #333',
                    borderRadius: '12px',
                    fontSize: '12px',
                    color: '#fff',
                  }}
                  formatter={(val: any) => [`${currency}${Number(val).toLocaleString()}`, 'Spent']}
                />
                <Bar dataKey="spent" fill="#FFFFFF" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
