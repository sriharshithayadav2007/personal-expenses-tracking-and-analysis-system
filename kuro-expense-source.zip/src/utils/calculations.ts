export interface TransactionItem {
  id: string;
  amount: number;
  category?: string;
  date: string; // YYYY-MM-DD
  type?: 'expense' | 'income';
}

export interface BudgetLimit {
  category: string;
  limit: number;
}

export interface FinancialSummary {
  totalIncome: number;
  totalExpenses: number;
  balance: number;
  savingsRate: number;
}

/**
 * Calculates total income, total expenses, net balance, and savings rate.
 */
export function calculateFinancialSummary(
  incomeList: { amount: number }[],
  expenseList: { amount: number }[]
): FinancialSummary {
  const totalIncome = incomeList.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
  const totalExpenses = expenseList.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
  const balance = totalIncome - totalExpenses;
  const savingsRate = totalIncome > 0 ? Math.max(0, Math.round(((totalIncome - totalExpenses) / totalIncome) * 100)) : 0;

  return {
    totalIncome,
    totalExpenses,
    balance,
    savingsRate,
  };
}

/**
 * Calculates spending per category.
 */
export function calculateCategoryBreakdown(
  expenses: { category: string; amount: number }[]
): Record<string, number> {
  const breakdown: Record<string, number> = {};
  for (const exp of expenses) {
    const cat = exp.category || 'Other';
    breakdown[cat] = (breakdown[cat] || 0) + (Number(exp.amount) || 0);
  }
  return breakdown;
}

/**
 * Computes budget status for a given category: spent, percentage, remaining, status.
 */
export function calculateBudgetStatus(
  limit: number,
  spent: number
): {
  spent: number;
  remaining: number;
  percentage: number;
  status: 'normal' | 'warning' | 'exceeded';
} {
  const safeLimit = Math.max(0, limit);
  const safeSpent = Math.max(0, spent);
  const percentage = safeLimit > 0 ? Math.round((safeSpent / safeLimit) * 100) : (safeSpent > 0 ? 100 : 0);
  const remaining = Math.max(0, safeLimit - safeSpent);

  let status: 'normal' | 'warning' | 'exceeded' = 'normal';
  if (percentage >= 100) {
    status = 'exceeded';
  } else if (percentage >= 80) {
    status = 'warning';
  }

  return {
    spent: safeSpent,
    remaining,
    percentage,
    status,
  };
}

/**
 * Finds the biggest spending day from a list of expenses.
 */
export function findBiggestSpendingDay(
  expenses: { date: string; amount: number }[]
): { date: string; amount: number } | null {
  if (expenses.length === 0) return null;

  const dayTotals: Record<string, number> = {};
  for (const exp of expenses) {
    const d = exp.date ? exp.date.split('T')[0] : 'Unknown';
    dayTotals[d] = (dayTotals[d] || 0) + (Number(exp.amount) || 0);
  }

  let topDate = '';
  let topAmount = -1;

  for (const [date, total] of Object.entries(dayTotals)) {
    if (total > topAmount) {
      topAmount = total;
      topDate = date;
    }
  }

  return topDate ? { date: topDate, amount: topAmount } : null;
}

/**
 * Calculates percentage change between previous and current period.
 */
export function calculatePercentageChange(current: number, previous: number): number {
  if (previous === 0) {
    return current > 0 ? 100 : 0;
  }
  return Math.round(((current - previous) / previous) * 100);
}
