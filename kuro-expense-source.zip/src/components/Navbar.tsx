import React, { useState } from 'react';
import {
  Wallet,
  Plus,
  Bell,
  User,
  LogOut,
  ChevronDown,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  X,
  AlertTriangle,
  Info,
  Download,
  FolderArchive,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useExpense } from '../context/ExpenseContext';
import { SUPPORTED_CURRENCIES, NavigationTab } from '../types';

interface NavbarProps {
  onOpenAddExpense: () => void;
  onOpenAddIncome: () => void;
  onOpenAuth: () => void;
  showLanding: boolean;
  setShowLanding: (val: boolean) => void;
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenAddExpense,
  onOpenAddIncome,
  onOpenAuth,
  showLanding,
  setShowLanding,
  activeTab,
  setActiveTab,
}) => {
  const { currentUser, userProfile, isGuest, currency, setCurrency, logout } = useAuth();
  const { balance, notifications, markNotificationAsRead, clearAllNotifications } = useExpense();

  const [showCurrencyDropdown, setShowCurrencyDropdown] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showAddMenu, setShowAddMenu] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <header className="sticky top-0 z-30 w-full border-b border-neutral-900 bg-black/80 backdrop-blur-xl transition-all">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Brand Logo & Name */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => {
              setShowLanding(false);
              setActiveTab('dashboard');
            }}
            className="group flex items-center gap-2.5 text-left focus:outline-none"
            aria-label="Kuro Expense Home"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-white text-black font-extrabold tracking-tighter shadow-sm transition-transform group-hover:scale-105">
              <span className="text-sm font-black">K</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold tracking-tight text-white font-['Space_Grotesk'] text-base">
                  KURO
                </span>
                <span className="rounded border border-neutral-800 bg-neutral-900 px-1.5 py-0.2 text-[10px] font-semibold uppercase tracking-wider text-neutral-400">
                  Fintech
                </span>
              </div>
              <p className="text-[10px] uppercase tracking-wider text-neutral-500 font-medium">
                Expense & Analytics
              </p>
            </div>
          </button>

          {/* Quick Balance indicator on desktop */}
          {!showLanding && (
            <div className="hidden lg:flex items-center gap-2 pl-4 border-l border-neutral-800">
              <span className="text-xs text-neutral-400">Net Balance:</span>
              <span
                className={`font-semibold text-sm ${
                  balance >= 0 ? 'text-white' : 'text-rose-400'
                }`}
              >
                {currency}
                {balance.toLocaleString()}
              </span>
            </div>
          )}
        </div>

        {/* Right Nav Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Landing / App Toggle button */}
          <button
            onClick={() => setShowLanding(!showLanding)}
            className="hidden sm:flex items-center gap-1.5 rounded-xl border border-neutral-800 bg-neutral-950 px-3 py-1.5 text-xs font-medium text-neutral-300 hover:border-neutral-700 hover:text-white transition-all"
            aria-label="Toggle Landing page view"
          >
            {showLanding ? (
              <>
                <span>Enter Dashboard</span>
                <ExternalLink className="h-3.5 w-3.5 text-neutral-400" />
              </>
            ) : (
              <>
                <Sparkles className="h-3.5 w-3.5 text-neutral-400" />
                <span>Product Overview</span>
              </>
            )}
          </button>

          {/* Direct Download ZIP button */}
          <a
            href="/downloads/kuro-expense-source.zip"
            download="kuro-expense-source.zip"
            className="flex items-center gap-1.5 rounded-xl border border-white bg-white px-2.5 sm:px-3 py-1.5 text-xs font-bold text-black hover:bg-neutral-200 transition-all shadow-md active:scale-95"
            title="Download full project ZIP for GitHub"
          >
            <Download className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Download ZIP</span>
            <span className="sm:hidden">ZIP</span>
          </a>

          {/* Currency Selector */}
          <div className="relative">
            <button
              onClick={() => {
                setShowCurrencyDropdown(!showCurrencyDropdown);
                setShowNotifications(false);
                setShowProfileMenu(false);
              }}
              className="flex items-center gap-1 rounded-xl border border-neutral-800 bg-neutral-950 px-2.5 py-1.5 text-xs font-semibold text-neutral-300 hover:border-neutral-700 hover:text-white transition-colors"
              aria-label="Select Currency"
            >
              <span>{currency}</span>
              <ChevronDown className="h-3 w-3 text-neutral-400" />
            </button>

            {showCurrencyDropdown && (
              <div className="absolute right-0 mt-2 w-48 rounded-xl border border-neutral-800 bg-neutral-950 p-1.5 shadow-2xl z-50 animate-in fade-in zoom-in-95">
                <div className="px-2.5 py-1.5 text-[11px] font-semibold text-neutral-500 uppercase tracking-wider">
                  Select Currency
                </div>
                {SUPPORTED_CURRENCIES.map(curr => (
                  <button
                    key={curr.code}
                    onClick={() => {
                      setCurrency(curr.symbol);
                      setShowCurrencyDropdown(false);
                    }}
                    className={`flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-xs transition-colors ${
                      currency === curr.symbol
                        ? 'bg-white text-black font-bold'
                        : 'text-neutral-300 hover:bg-neutral-900'
                    }`}
                  >
                    <span>{curr.name}</span>
                    <span className="font-mono">{curr.symbol}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Notifications Dropdown */}
          <div className="relative">
            <button
              onClick={() => {
                setShowNotifications(!showNotifications);
                setShowCurrencyDropdown(false);
                setShowProfileMenu(false);
              }}
              className="relative flex h-9 w-9 items-center justify-center rounded-xl border border-neutral-800 bg-neutral-950 text-neutral-300 hover:border-neutral-700 hover:text-white transition-colors"
              aria-label="Notifications"
            >
              <Bell className="h-4 w-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-white text-[9px] font-bold text-black animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>

            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl border border-neutral-800 bg-neutral-950 p-4 shadow-2xl z-50 animate-in fade-in zoom-in-95">
                <div className="flex items-center justify-between pb-3 border-b border-neutral-900">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-white">Notifications</span>
                    {unreadCount > 0 && (
                      <span className="rounded-full bg-neutral-800 px-2 py-0.5 text-[10px] text-neutral-300">
                        {unreadCount} new
                      </span>
                    )}
                  </div>
                  {notifications.length > 0 && (
                    <button
                      onClick={clearAllNotifications}
                      className="text-[11px] text-neutral-400 hover:text-white transition-colors"
                    >
                      Clear all
                    </button>
                  )}
                </div>

                <div className="mt-3 max-h-72 overflow-y-auto space-y-2.5 pr-1">
                  {notifications.length === 0 ? (
                    <div className="py-6 text-center text-xs text-neutral-500">
                      No new notifications. Everything is in order.
                    </div>
                  ) : (
                    notifications.map(n => (
                      <div
                        key={n.id}
                        onClick={() => markNotificationAsRead(n.id)}
                        className={`rounded-xl border p-3 text-xs transition-colors cursor-pointer ${
                          n.type === 'danger'
                            ? 'border-rose-900/50 bg-rose-950/20 text-rose-200'
                            : n.type === 'warning'
                            ? 'border-amber-900/50 bg-amber-950/20 text-amber-200'
                            : 'border-neutral-800 bg-neutral-900/60 text-neutral-300'
                        } ${!n.read ? 'ring-1 ring-white/20' : 'opacity-80'}`}
                      >
                        <div className="flex items-start gap-2">
                          {n.type === 'danger' || n.type === 'warning' ? (
                            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
                          ) : (
                            <Info className="mt-0.5 h-4 w-4 shrink-0 text-neutral-400" />
                          )}
                          <div className="flex-1">
                            <p className="font-semibold text-white">{n.title}</p>
                            <p className="mt-0.5 text-neutral-400 text-[11px] leading-relaxed">
                              {n.message}
                            </p>
                            <span className="mt-1 block text-[10px] text-neutral-500 font-mono">
                              {n.time}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Quick Add Action Menu */}
          <div className="relative">
            <button
              onClick={() => {
                setShowAddMenu(!showAddMenu);
                setShowCurrencyDropdown(false);
                setShowNotifications(false);
                setShowProfileMenu(false);
              }}
              className="flex items-center gap-1.5 rounded-xl bg-white px-3.5 py-1.5 text-xs font-bold text-black transition-all hover:bg-neutral-200 active:scale-95 shadow-sm"
              aria-label="Add Transaction"
            >
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">Add</span>
            </button>

            {showAddMenu && (
              <div className="absolute right-0 mt-2 w-48 rounded-xl border border-neutral-800 bg-neutral-950 p-1.5 shadow-2xl z-50 animate-in fade-in zoom-in-95">
                <button
                  onClick={() => {
                    setShowAddMenu(false);
                    onOpenAddExpense();
                  }}
                  className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-medium text-white hover:bg-neutral-900 transition-colors"
                >
                  <div className="flex h-6 w-6 items-center justify-center rounded-md bg-neutral-800 text-rose-400 font-bold">
                    -
                  </div>
                  <span>Add Expense</span>
                </button>
                <button
                  onClick={() => {
                    setShowAddMenu(false);
                    onOpenAddIncome();
                  }}
                  className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-medium text-white hover:bg-neutral-900 transition-colors"
                >
                  <div className="flex h-6 w-6 items-center justify-center rounded-md bg-neutral-800 text-emerald-400 font-bold">
                    +
                  </div>
                  <span>Add Income</span>
                </button>
              </div>
            )}
          </div>

          {/* User Account / Auth Button */}
          <div className="relative">
            {currentUser || userProfile ? (
              <button
                onClick={() => {
                  setShowProfileMenu(!showProfileMenu);
                  setShowCurrencyDropdown(false);
                  setShowNotifications(false);
                  setShowAddMenu(false);
                }}
                className="flex items-center gap-2 rounded-xl border border-neutral-800 bg-neutral-950 p-1.5 sm:px-2.5 text-xs text-neutral-300 hover:border-neutral-700 transition-colors"
                aria-label="User profile menu"
              >
                <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-neutral-800 font-bold text-white text-[11px]">
                  {userProfile?.name?.charAt(0).toUpperCase() || 'U'}
                </div>
                <span className="hidden md:inline font-medium text-white max-w-[100px] truncate">
                  {userProfile?.name || 'User'}
                </span>
                <ChevronDown className="hidden sm:inline h-3 w-3 text-neutral-400" />
              </button>
            ) : (
              <button
                onClick={onOpenAuth}
                className="rounded-xl border border-neutral-800 bg-neutral-950 px-3 py-1.5 text-xs font-semibold text-white hover:border-neutral-700 hover:bg-neutral-900 transition-all"
              >
                Sign In
              </button>
            )}

            {showProfileMenu && (
              <div className="absolute right-0 mt-2 w-56 rounded-2xl border border-neutral-800 bg-neutral-950 p-2 shadow-2xl z-50 animate-in fade-in zoom-in-95">
                <div className="px-3 py-2 border-b border-neutral-900">
                  <div className="font-semibold text-xs text-white truncate">
                    {userProfile?.name || 'Account'}
                  </div>
                  <div className="text-[11px] text-neutral-500 truncate">
                    {userProfile?.email || 'Guest Mode'}
                  </div>
                  {isGuest && (
                    <span className="mt-1.5 inline-block rounded bg-neutral-800 px-1.5 py-0.5 text-[9px] font-semibold text-amber-300">
                      Live Demo Mode
                    </span>
                  )}
                </div>

                <div className="py-1">
                  <button
                    onClick={() => {
                      setShowProfileMenu(false);
                      setShowLanding(false);
                      setActiveTab('settings');
                    }}
                    className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs text-neutral-300 hover:bg-neutral-900 transition-colors"
                  >
                    <User className="h-3.5 w-3.5 text-neutral-400" />
                    <span>Profile & Settings</span>
                  </button>

                  {isGuest ? (
                    <button
                      onClick={() => {
                        setShowProfileMenu(false);
                        onOpenAuth();
                      }}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs text-white hover:bg-neutral-900 transition-colors"
                    >
                      <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                      <span>Create Account / Sync</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        setShowProfileMenu(false);
                        logout();
                      }}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs text-rose-400 hover:bg-neutral-900 transition-colors"
                    >
                      <LogOut className="h-3.5 w-3.5" />
                      <span>Log Out</span>
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
