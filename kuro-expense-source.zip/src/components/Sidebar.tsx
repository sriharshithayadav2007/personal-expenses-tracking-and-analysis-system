import React from 'react';
import {
  LayoutDashboard,
  Receipt,
  TrendingUp,
  PieChart,
  BarChart3,
  FileText,
  Settings,
  Sparkles,
  Shield,
  ArrowUpRight,
} from 'lucide-react';
import { NavigationTab } from '../types';
import { useAuth } from '../context/AuthContext';
import { useExpense } from '../context/ExpenseContext';

interface SidebarProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  onOpenAddExpense: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  onOpenAddExpense,
}) => {
  const { currency, userProfile, isGuest } = useAuth();
  const { totalExpenses, totalIncome, balance, savingsRate } = useExpense();

  const navItems: { tab: NavigationTab; label: string; icon: React.ElementType; badge?: string }[] = [
    { tab: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { tab: 'expenses', label: 'Expenses', icon: Receipt },
    { tab: 'income', label: 'Income', icon: TrendingUp },
    { tab: 'budget', label: 'Budgets', icon: PieChart },
    { tab: 'analytics', label: 'Analytics', icon: BarChart3 },
    { tab: 'reports', label: 'Reports', icon: FileText },
    { tab: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <aside className="hidden lg:flex w-64 flex-col border-r border-neutral-900 bg-black min-h-[calc(100vh-4rem)] p-4 select-none">
      {/* Navigation list */}
      <nav className="flex-1 space-y-1">
        <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-neutral-500">
          Navigation
        </div>
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.tab;
          return (
            <button
              key={item.tab}
              onClick={() => setActiveTab(item.tab)}
              className={`group flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-xs font-semibold transition-all ${
                isActive
                  ? 'bg-white text-black shadow-lg shadow-white/5'
                  : 'text-neutral-400 hover:bg-neutral-950 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`h-4 w-4 transition-colors ${
                    isActive ? 'text-black' : 'text-neutral-500 group-hover:text-white'
                  }`}
                />
                <span>{item.label}</span>
              </div>
              {isActive && (
                <div className="h-1.5 w-1.5 rounded-full bg-black animate-pulse" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Mini Financial Metric Snapshot Card */}
      <div className="mt-auto pt-4 border-t border-neutral-900">
        <div className="rounded-2xl border border-neutral-800/80 bg-neutral-950/70 p-3.5 backdrop-blur-sm">
          <div className="flex items-center justify-between text-[11px] text-neutral-400">
            <span>Savings Rate</span>
            <span className="font-mono font-bold text-white">{savingsRate}%</span>
          </div>

          <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-neutral-900">
            <div
              className="h-full rounded-full bg-white transition-all duration-500"
              style={{ width: `${Math.min(100, Math.max(0, savingsRate))}%` }}
            />
          </div>

          <div className="mt-3 flex items-center justify-between text-[10px] text-neutral-500">
            <span>Net Saved</span>
            <span className="font-mono text-neutral-300">
              {currency}
              {Math.max(0, balance).toLocaleString()}
            </span>
          </div>
        </div>

        {/* Guest status alert or cloud sync indicator */}
        <div className="mt-3 px-2 flex items-center justify-between text-[11px] text-neutral-500">
          <div className="flex items-center gap-1.5">
            <div className="h-2 w-2 rounded-full bg-emerald-500" />
            <span>{isGuest ? 'Demo Offline' : 'Firebase Synced'}</span>
          </div>
          <span className="font-mono text-[10px]">v2.4.0</span>
        </div>
      </div>
    </aside>
  );
};
